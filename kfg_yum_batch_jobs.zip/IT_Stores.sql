/* KFG Stores Report - Sep 25, 2019
Purpose: A query to pull a list of stores (Merchants) for KFG
+ adding the lat, long of merchant */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE	@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of Merchants table
	   filtered by Org */
	SET @InitialCount = 
	(
	SELECT COUNT(*)
	FROM Merchants m WITH (NOLOCK)
		FULL OUTER JOIN Organisations o WITH (NOLOCK) ON m.OrganisationId = o.Id
	WHERE 
		o.Name = @OrgName
	);

	/* Query TransportJobMetadatas table
	   with joins to TransportJobs and other tables
	   for the SDMStoreID
	   filtered by Org and DateTime (based on declared variables)
	   into #SDMStoreId temp table*/
	SELECT
		m.Id As MerchantId,
		MAX(CASE WHEN tm.JobMetadata = 18 THEN tm.Value ELSE NULL END) As SDMStoreId
	INTO #SDMStoreId
	FROM TransportJobMetadatas tm WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = tm.TransportJobId
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		(tm.JobMetadata IN (18))
	GROUP BY m.Id;

	/* Query Merchants table
	   with joins to TransportJobs,MerchantFleets, Fleets, Brands, and other tables
	   for the Merchant info, Fleet Info, and latest transport job
	   filtered by Org
	   into #Merchants temp table*/
	SELECT
		MAX(m.Id) As MerchantId,
		MAX(mi.ExternalIdentifier) As KFGStoreId,
		MAX(sdmId.SDMStoreId) As SDMStoreId,
		MAX(m.Identifier) As MerchantIdentifier,
		MAX(m.Name) As MerchantName,
		MAX(b.Name) As MerchantBrand,
		MAX(f.Id) As FleetId,
		MAX(t.Id) As LatestTransportJob
	INTO #Merchants
	FROM Merchants m WITH (NOLOCK)
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN Brands b WITH (NOLOCK) ON b.MerchantId = m.Identifier
		LEFT JOIN TransportJobs t WITH (NOLOCK) ON t.MerchantId = m.Id
		LEFT JOIN MerchantFleets mf WITH (NOLOCK) ON mf.MerchantId = m.Identifier
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = mf.FleetId AND f.Deleted = 0
		LEFT JOIN MerchantIntegrations mi WITH (NOLOCK) ON m.Id = mi.MerchantId
		LEFT JOIN #SDMStoreId sdmId ON m.Id = sdmId.MerchantId
	WHERE 
		o.Name = @OrgName
	GROUP BY
		m.Id;

	/* Query #Merchants temp table
	   with joins to TransportJobLocations table
	   for Merchant info, Fleets info, lat long of merchant, and 
	   filtered by Org
	   into #Output temp table*/
	SELECT
		m.MerchantId As StoreId,
		COALESCE(m.SDMStoreId, m.KFGStoreId) As KFGStoreId,
		m.MerchantName As StoreName,
		m.MerchantBrand As StoreBrand,
		m.FleetId As StoreHubId,
		CAST(tl.Latitude As varchar(MAX)) + ', ' + CAST(tl.Longitude As varchar(MAX)) As StoreCoordinates
	INTO #Output
	FROM #Merchants m WITH (NOLOCK)
		LEFT JOIN TransportJobLocations tl WITH (NOLOCK) ON tl.TransportJobId = m.LatestTransportJob AND tl.Type = 0 /* 0 is the Type for Pickup Locations*/
	ORDER BY
		m.MerchantId;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount = 
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount 
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount 
		SELECT * FROM #Output o 
		ORDER BY o.StoreId;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Merchants,
		#SDMStoreId,
		#Output;
END

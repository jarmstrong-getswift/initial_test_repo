/* KFG Batch Report - Oct 9, 2019
Purpose: A query to pull month-to-date Organization-level Jobs report for KFG
+ adding Order Batch Size and Order Batch Number fields using ImplicitlyPickedUp metadata
+ adding feedback survey data*/

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @UTCOffset INT = 3; /* Turn UTC time into local time*/
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-2)), /* This will give 2 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = DATEADD(hh,@UTCOffset,GETDATE()), /* This will give today's datetime at report run */
			@OrgName NVARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of TransportJobs table
	   filtered by Org and DateTime (based on declared variables) */
	SET @InitialCount =
	(
	SELECT COUNT(*)
	FROM TransportJobs t WITH (NOLOCK)
		FULL OUTER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		FULL OUTER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	);

	/* Create #OrderStageEnum temp table
	   to convert Driver Activity Enum to display text*/
	CREATE TABLE #OrderStageEnum (
		Id INT,
		DisplayText VARCHAR(MAX)
	);

	INSERT INTO #OrderStageEnum
	VALUES	(0,'Received'),
			(1,'Accepted'),
			(3,'En Route'),
			(5,'Completed'),
			(6,'Cancelled'),
			(7,'Abandoned');

	/* Using CTE, query TransportJobStageEntries table
	   for Last Accepted entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Accepted temp table*/
	WITH AcceptedCTE (Id, Created, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 1 AND
			ts.Notes NOT LIKE '%at pickup%'
		)
	SELECT *
	INTO #Accepted
	FROM AcceptedCTE ac
	WHERE ac.RowNumber = 1
	ORDER BY ac.Id;

	/* Using CTE, query TransportJobStageEntries table
	   for First Accepted entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #AcceptedFirst temp table*/
	WITH AcceptedFirstCTE (Id, Created, Notes, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ts.Notes,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created ASC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 1 AND
			ts.Notes NOT LIKE '%at pickup%'
		)
	SELECT *
	INTO #AcceptedFirst
	FROM AcceptedFirstCTE ac
	WHERE ac.RowNumber = 1
	ORDER BY ac.Id;

	/* Using CTE, query TransportJobStageEntries table
	   for Completed entries (and row number if there are multiple entries)
	   for Latitude and Longitude
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Completed temp table*/
	WITH CompletedCTE (Id, Created, Latitude, Longitude, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ts.Latitude,
			ts.Longitude,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 5
		)
	SELECT *
	INTO #Completed
	FROM CompletedCTE cc
	WHERE cc.RowNumber = 1;

	/* Query Accounts table
	   with joins to AccountUsernames and other tables
	   for the Username of account without email (no duplicates)
	   filtered by Org and DateTime (based on declared variables)
	   into #Usernames temp table*/
	SELECT
		MAX(h.Id) As DriverId,
		MAX(au.Username) As DriverUsername
	INTO #Usernames
	FROM Accounts a WITH (NOLOCK)
		INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
		INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE
		o.Name = @OrgName AND
		au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
	GROUP BY
		a.Id
	ORDER BY
		a.Id;

	/* Query TransportJobs table
	   with joins to Handlers, Fleets, Accounts, #Accepted, and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #TransportJobsExtract temp table*/
	SELECT
		t.Id As GetSwiftId,
		t.Reference As Reference,
		f.Id As FleetId1,
		f.Name As FleetName,
		m.Id As MerchantId,
		m.Name As MerchantName,
		h.Id As DriverId,
		u.DriverUsername As DriverUsername,
		a.FirstName As DriverFirstName,
		a.LastName As DriverLastName,
		e.DisplayText As OrderStatus,
		DATEFROMPARTS(YEAR(DATEADD(hour,@UTCOffset-6,t.Created)),MONTH(DATEADD(hour,@UTCOffset-6,t.Created)),DAY(DATEADD(hour,@UTCOffset-6,t.Created))) As DOB1,
		DATEADD(hour,@UTCOffset,t.DropoffTime_LatestTime) As PromiseTimeLocal,
		DATEADD(hour,@UTCOffset,t.Created) As CreatedLocal,
		DATEADD(hour,@UTCOffset,t.OrderProcessed) As InKitchenLocal,
		DATEADD(hour,@UTCOffset,t.OrderReady) As ReadyLocal,
		DATEADD(hour,@UTCOffset,ac.Created) As AcceptedLocal,
		DATEADD(hour,@UTCOffset,t.ArrivedAtPickup) As AtPickupLocal,
		DATEADD(hour,@UTCOffset,t.OrderOnWay) As EnRouteLocal,
		DATEADD(hour,@UTCOffset,t.ArrivedAtDropoff) As AtDropoffLocal,
		DATEADD(hour,@UTCOffset,t.Completed) As CompletedLocal,
		cc.Latitude As CompletedLatitude1,
		cc.Longitude As CompletedLongitude1,
		DATEADD(hour,@UTCOffset,af.Created) As FirstAcceptedLocal1,
		(CASE
			WHEN af.Notes LIKE '%via routing%' THEN 'Auto'
			WHEN af.Notes LIKE '%via auto accept%' THEN 'Manual'
			WHEN af.Notes LIKE '%via admin map%' THEN 'Manual'
			WHEN af.Notes LIKE '%via driver app%' THEN 'Manual'
			ELSE NULL
			END) As FirstAcceptedType1,
		af.Notes As FirstAcceptedDetails1,
		t.Estimates_Kilometres As DistanceRoadKm
	INTO #TransportJobsExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN #OrderStageEnum e ON e.Id = t.CurrentStage
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = t.FleetId
		LEFT JOIN Handlers h WITH (NOLOCK) ON t.HandlerId = h.Id
		LEFT JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
		LEFT JOIN #Usernames u ON u.DriverId = h.id
		LEFT JOIN #Accepted ac ON ac.Id = t.Id
		LEFT JOIN #AcceptedFirst af ON af.Id = t.Id
		LEFT JOIN #Completed cc ON cc.Id = t.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobs table
	   with joins to TransportJobLocations and other tables
	   for the pickup/dropoff location information for each job
	   filtered by DateTime (based on declared variables) AND not org (can't create query plan)
	   into #LocationsExtract temp table*/
	SELECT
		t.Id As lGetSwiftId,
		'' AS DistanceStraightKm,
		/*ROUND(tp.GeoLocation.STDistance(td.GeoLocation) / 1000,3) As DistanceStraightKm,*/
		tp.ContactName As PickupName,
		td.Suburb As DestinationSuburb,
		td.ContactPhone As DestinationPhoneNumber1
	INTO #LocationsExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN TransportJobLocations tp WITH (NOLOCK) ON t.Id = tp.TransportJobId AND tp.Type = 0 /* Pickup location filter */
		INNER JOIN TransportJobLocations td WITH (NOLOCK) ON t.Id = td.TransportJobId AND td.Type = 1 /* Dropoff location filter */
	WHERE
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobMetadatas table
	   with joins to TransportJobs and other tables
	   for the Total Price information for each job
	   filtered by Org and DateTime (based on declared variables)
	   into #MetadataExtract temp table*/
	SELECT
		tm.TransportJobId As GetSwiftId,
		MAX(CASE WHEN tm.JobMetadata = 13 THEN tm.Value ELSE NULL END) As OrderSource1,
		MAX(CASE WHEN tm.JobMetadata = 16 THEN tm.Value ELSE NULL END) As NCRArea1,
		MAX(CASE WHEN tm.JobMetadata = 15 THEN tm.Value ELSE NULL END) As NCRAreaId1,
		CAST(MAX(CASE WHEN tm.JobMetadata = 20 THEN tm.Value ELSE NULL END) As decimal(19,4)) As TotalPrice,
		MAX(CASE WHEN tm.JobMetadata = 21 THEN tm.ValueJson ELSE NULL END) As NcrPayment,
		CAST(MAX(CASE WHEN tm.JobMetadata = 9 THEN tm.Value ELSE NULL END) As decimal(19,4)) As CashToCollect
	INTO #MetadataExtract
	FROM TransportJobMetadatas tm WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = tm.TransportJobId
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		(tm.JobMetadata IN (9, 13, 15, 16, 20, 21))
	GROUP BY
		tm.TransportJobId
	ORDER BY
		tm.TransportJobId;

	/* Query TransportJobs table
	   with joins to #MetadataExtract and other tables
	   for the Price information for each job
	   and calc Subtotal price
	   filtered by Org and DateTime (based on declared variables)
	   into #PriceExtract temp table*/
	SELECT
		t.Id As pGetSwiftId,
		COALESCE(me.TotalPrice, 0) As TotalPrice,
		(COALESCE(me.TotalPrice, 0)) - (COALESCE(t.DeliveryPrice, 0)) As SubtotalPrice,
		COALESCE(t.DeliveryPrice, 0) As DeliveryPrice,
		me.OrderSource1 As OrderSource1,
		me.NCRArea1 As NCRArea1,
		me.NCRAreaId1 As NCRAreaId1,
		CASE
		WHEN COALESCE(me.TotalPrice, 0) = 0 THEN 'Price is 0'
		WHEN COALESCE(me.CashToCollect, 0) = 0 THEN 'Prepaid'
		WHEN COALESCE(me.CashToCollect, 0) <> COALESCE(me.TotalPrice, 0) THEN 'Split'
		WHEN COALESCE(me.CashToCollect, 0) > 0 THEN 'Cash'
		ELSE 'Other' END
		As PaymentMethod1,
		JSON_VALUE(me.NcrPayment, '$[0].Name') As PaymentTenderMode1
	INTO #PriceExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN #MetadataExtract me ON me.GetSwiftId = t.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobs table
	   with joins to TransportJobMetadatas and other tables
	   and calc order batch size and order batch number
	   for the Implicitly PickedUp information for each job
	   filtered by Org and DateTime (based on declared variables)
	   into #ImplicitlyPickedUpExtract temp table*/
	SELECT
		t.Id AS iGetSwiftId,
		COUNT(*) OVER(PARTITION BY t.HandlerId, tm.Value) As OrderBatchSize,
		ROW_NUMBER() OVER(PARTITION BY t.HandlerId, tm.Value
			ORDER BY t.Completed ASC) As OrderBatchNumber,
		FIRST_VALUE(DATEADD(hour,@UTCOffset,t.OrderOnWay)) OVER(PARTITION BY t.HandlerId, tm.Value
		ORDER BY t.Completed ASC) AS NewEnRouteLocal1
	INTO #ImplicitlyPickedUpExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN TransportJobMetadatas tm WITH (NOLOCK) ON t.Id = tm.TransportJobId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		tm.JobMetadata = 22 /* Implicitly PickedUp filter */
	ORDER BY
		t.Id;

	/* Query TransportJobs table
	   with joins to SurveyEntries (multiple join based on surveyType) and other tables
	   for rating for each category, and feedback comments
	   filtered by Org and DateTime (based on declared variables)
	   into #SurveyExtract temp table*/
	SELECT
		t.Id AS sGetSwiftId,
		sf.Rating As FoodRating,
		ss.Rating As ServiceRating,
		sd.Rating As DeliveryRating,
		sc.Notes As FeedbackComments
	INTO #SurveyExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN SurveyEntries sf WITH (NOLOCK) ON t.Id = sf.TransportJobId AND sf.SurveyTypeId = 1
		INNER JOIN SurveyEntries ss WITH (NOLOCK) ON t.Id = ss.TransportJobId AND ss.SurveyTypeId = 2
		INNER JOIN SurveyEntries sd WITH (NOLOCK) ON t.Id = sd.TransportJobId AND sd.SurveyTypeId = 3
		LEFT JOIN SurveyEntries sc WITH (NOLOCK) ON t.Id = sc.TransportJobId AND sc.SurveyTypeId = 4
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobItems table
	   with joins to TransportJobs and other tables
	   for number of items in each order
	   filtered by Org and DateTime (based on declared variables)
	   into #PriceExtract temp table*/
	SELECT
		MAX(t.Id) As itGetSwiftId,
		COUNT(DISTINCT ti.Description) As TotalItemLines1,
		COUNT(*) As TotalItemQty1
	INTO #ItemsExtract
	FROM TransportJobItems ti WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = ti.TransportJobId
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	GROUP BY t.Id
	ORDER BY t.Id;

	/* Join 5 intermediary temp tables into final #Output temp table */
	SELECT
		*,
		i.NewEnRouteLocal1 As NewEnRouteLocal,
		t.CompletedLatitude1 As CompletedLatitude,
		t.CompletedLongitude1 As CompletedLongitude,
		t.FirstAcceptedLocal1 As FirstAcceptedLocal,
		t.FirstAcceptedType1 As FirstAcceptedType,
		t.FirstAcceptedDetails1 As FirstAcceptedDetails,
		t.DOB1 As DOB,
		l.DestinationPhoneNumber1 As DestinationPhoneNumber,
		p.OrderSource1 As OrderSource,
		p.PaymentMethod1 As PaymentMethod,
		p.PaymentTenderMode1 As PaymentTenderMode,
		it.TotalItemLines1 As TotalItemLines,
		it.TotalItemQty1 As TotalItemQty,
		t.FleetId1 As FleetId,
		p.NCRArea1 As NCRArea,
		p.NCRAreaId1 As NCRAreaId
	INTO #Output FROM #TransportJobsExtract t
		LEFT JOIN #LocationsExtract l ON t.GetSwiftId = l.lGetSwiftId
		LEFT JOIN #PriceExtract p ON t.GetSwiftId = p.pGetSwiftId
		LEFT JOIN #ImplicitlyPickedUpExtract i ON t.GetSwiftId = i.iGetSwiftId
		LEFT JOIN #SurveyExtract s ON t.GetSwiftId = s.sGetSwiftId
		LEFT JOIN #ItemsExtract it ON t.GetSwiftId = it.itGetSwiftId;

	/* Drop duplicate GetSwiftId columns used to join temp tables */
	ALTER TABLE #Output
		DROP COLUMN
			lGetSwiftId,
			pGetSwiftId,
			iGetSwiftId,
			sGetSwiftId,
			itGetSwiftId,
			NewEnRouteLocal1,
			CompletedLatitude1,
			CompletedLongitude1,
			FirstAcceptedLocal1,
			FirstAcceptedType1,
			FirstAcceptedDetails1,
			DOB1,
			DestinationPhoneNumber1,
			OrderSource1,
			PaymentMethod1,
			PaymentTenderMode1,
			TotalItemLines1,
			TotalItemQty1,
			FleetId1,
			NCRArea1,
			NCRAreaId1;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o
		WHERE o.GetSwiftId <> 1025649
		ORDER BY o.GetSwiftId;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#OrderStageEnum,
		#Accepted,
		#AcceptedFirst,
		#Completed,
		#Usernames,
		#TransportJobsExtract,
		#LocationsExtract,
		#ImplicitlyPickedUpExtract,
		#MetadataExtract,
		#PriceExtract,
		#SurveyExtract,
		#ItemsExtract,
		#Output;
END

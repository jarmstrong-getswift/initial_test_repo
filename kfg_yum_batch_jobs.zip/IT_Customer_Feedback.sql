/* KFG Customer Feedback Report - Sep 25, 2019
Purpose: A query to pull a list of orders with customer feedback for KFG
+ basic order info, survey rating for 3 categories, and survey comments */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of SurveyEntries table (with distinct Order Ids)
	   filtered by Org */
	SET @InitialCount =
	(
	SELECT COUNT(DISTINCT t.Id)
	FROM SurveyEntries s WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON s.TransportJobId = t.Id
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	);

	/* Query TransportJobs table
	   with joins to SurveyEntries (multiple join based on surveyType) and other tables
	   for rating for each category, and feedback comments
	   filtered by Org and DateTime (based on declared variables)
	   into #SurveyExtract temp table*/
	SELECT
		t.Reference As OrderId,
		DATEADD(hour,@UTCOffset,t.Created) 'OrderDate',
		sf.Rating As FoodRating,
		ss.Rating As ServiceRating,
		sd.Rating As DeliveryRating,
		sc.Notes As FeedbackComments
	INTO #Output
	FROM TransportJobs t
		INNER JOIN Merchants m ON m.Id = t.MerchantId
		INNER JOIN Organisations o ON o.Id = m.OrganisationId
		INNER JOIN SurveyEntries sf ON t.Id = sf.TransportJobId AND sf.SurveyTypeId = 1
		INNER JOIN SurveyEntries ss ON t.Id = ss.TransportJobId AND ss.SurveyTypeId = 2
		INNER JOIN SurveyEntries sd ON t.Id = sd.TransportJobId AND sd.SurveyTypeId = 3
		LEFT JOIN SurveyEntries sc ON t.Id = sc.TransportJobId AND sc.SurveyTypeId = 4
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o
		WHERE o.OrderId NOT LIKE 'RM Email'
		ORDER BY o.OrderDate;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Output;
END

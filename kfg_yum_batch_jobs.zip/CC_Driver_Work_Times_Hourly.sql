/* Driver Work Times - Sep 3, 2019
Purpose: A query to pull month-to-date Organization-level Driver Work Times report for KFG
+ with UTC/Local times, Current Hub & Shift Hub, and # of jobs completed during shift*/

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @UTCOffset INT = 3; /* Turn UTC time into local time*/
	DECLARE @StartDateLocal DATETIME = DATEADD(dd,-1,CONVERT(date, GETDATE())), /* This will give 1 day ago at 00:00 */
			@EndDateLocal DATETIME = CONVERT(date, GETDATE()), /* This will give today's date at 00:00 */
			@OrgName VARCHAR(50) = 'Kout Food Group';

	SELECT
		d.Date,
		CAST(t.MilitaryHour As int) As MilitaryHour,
		MIN(t.StandardTime) As StandardTime,
		DATEADD(hh,CAST(t.MilitaryHour As int),CAST(d.Date As datetime)) As DateHour
	INTO #DateTime
	FROM Time t
		CROSS APPLY Date d
	WHERE
		d.Date >= @StartDateLocal AND
		d.Date < @EndDateLocal
	GROUP BY d.Date, t.MilitaryHour
	ORDER BY d.Date, t.MilitaryHour;


	/* Using CTE, query TransportJobStageEntries table
	   for Last Accepted entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Accepted temp table*/
	WITH AcceptedCTE (Id, Created, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Completed) >= DATEADD(day,-7,@StartDateLocal) AND
			DATEADD(hour,@UTCOffset,t.Completed) < DATEADD(day,7,@EndDateLocal) AND
			ts.Stage = 1 AND
			ts.Notes NOT LIKE '%at pickup%'
		)
	SELECT *
	INTO #Accepted
	FROM AcceptedCTE ac
	WHERE ac.RowNumber = 1
	ORDER BY ac.Id;

	/* Query TransportJobs table
	   for the ID, CompletedUTC time, and Handler ID of jobs
	   filtered by Org and DateTime (based on declared variables)
	   into #Jobs temp table*/
	SELECT
		t.Id,
		t.HandlerId,
		t.FleetId,
		t.Created,
		t.OrderOnWay,
		t.Completed,
		DATEADD(hour,@UTCOffset,ac.Created) As AcceptedLocal,
		DATEADD(hour,@UTCOffset,t.Completed) As CompletedLocal
	INTO #Jobs
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN #Accepted ac ON ac.Id = t.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Completed) >= DATEADD(day,-7,@StartDateLocal) AND
		DATEADD(hour,@UTCOffset,t.Completed) < DATEADD(day,7,@EndDateLocal) AND
		t.HandlerId IS NOT NULL;

	CREATE UNIQUE INDEX idx_start_end
		ON #Jobs(HandlerId, AcceptedLocal, CompletedLocal, Id);

	/* Query #DriverOnline table
	   with sub-query for Fleet Name that driver was associated with at that time AND
	   with sub-query for Offline Time associated with the Online time
	   filtered by Org and DateTime (based on declared variables)
	   into #MatchingFleet temp table*/
	WITH HandlerLogsCTE As
		(
			SELECT
				hl.HandlerId As DriverId,
				f.Name As FleetName,
				OnlineUTC =
					CASE WHEN hl.Activity = 0 THEN hl.Created END,
				OfflineUTC =
					CASE
					/* If the next Event by EventTime is a logout */
					WHEN LEAD(hl.Activity, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created) = 1
					/* Then we pick up the corresponding EventTime */
					THEN LEAD(hl.Created, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created)
					/* Otherwise logout time will be set to NULL */
					END,
				hl.Activity
			FROM HandlerActivityLogEntries hl WITH (NOLOCK)
				INNER JOIN Handlers h WITH (NOLOCK) ON h.Id = hl.HandlerId
				INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
				LEFT JOIN HandlerFleets hf WITH (NOLOCK) ON h.Id = hf.HandlerId
				LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = hf.FleetId
			WHERE
				o.Name = @OrgName AND
				DATEADD(hour,@UTCOffset,hl.Created) >= DATEADD(day,-7,@StartDateLocal) AND
				DATEADD(hour,@UTCOffset,hl.Created) < DATEADD(day,7,@EndDateLocal) AND
				(hl.Activity = 0 OR hl.Activity = 1)
		)
	SELECT
		*,
		FleetId1 =
			(SELECT TOP 1 t.FleetId
			FROM #Jobs t
			WHERE
				h.OnlineUTC <= t.OrderOnWay AND   /* The first job for that driver after going online*/
				t.HandlerId = h.DriverId
			ORDER BY t.Created ASC),
		FleetId2 =
			(SELECT t.FleetId
			FROM #Jobs t
			WHERE
				h.OnlineUTC <= t.OrderOnWay AND   /* The second job for that driver after going online*/
				t.HandlerId = h.DriverId
			ORDER BY t.Created ASC
			OFFSET 1 ROWS
			FETCH NEXT 1 ROWS ONLY),
		FleetId = CAST(NULL AS VARCHAR(MAX))
	INTO #MatchingFleet
	FROM HandlerLogsCTE h
	WHERE
		h.Activity = 0 AND
		h.OfflineUTC IS NOT NULL
	ORDER BY
		h.DriverId,
		h.OnlineUTC;

	UPDATE #MatchingFleet SET FleetId = COALESCE(FleetId1, FleetId2); /* Combine FleetId1 and FleetId2*/

	/* Query Accounts table
	   with joins to AccountUsernames and other tables
	   for the Username of account without email (no duplicates)
	   filtered by Org and DateTime (based on declared variables)
	   into #Usernames temp table*/
	SELECT
		MAX(h.Id) As DriverId,
		MAX(au.Username) As DriverUsername
	INTO #Usernames
	FROM Accounts a
		INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
		INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE
		o.Name = @OrgName AND
		au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
	GROUP BY
		a.Id
	ORDER BY
		a.Id;

	WITH C1 AS
	(
	  SELECT *,
		MAX(CompletedLocal) OVER(PARTITION BY HandlerId
			  ORDER BY AcceptedLocal, CompletedLocal, Id
			  ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prvend
	  FROM #Jobs
	),
	C2 AS
	(
	  SELECT *,
		SUM(isstart) OVER(PARTITION BY HandlerId
			  ORDER BY AcceptedLocal, CompletedLocal, Id
			  ROWS UNBOUNDED PRECEDING) AS grp
	  FROM C1
		CROSS APPLY ( VALUES(CASE WHEN AcceptedLocal <= prvend THEN NULL ELSE 1 END) ) AS A(isstart)
	)
	SELECT
		HandlerId As HandlerId,
		MIN(AcceptedLocal) AS AcceptedLocal,
		MAX(CompletedLocal) AS CompletedLocal
	INTO #JobTimes
	FROM C2
	GROUP BY HandlerId, grp
	ORDER by HandlerId;

	/* Query Handler table
	   with joins to #MatchingFleet and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #Final temp table*/
	SELECT
		h.Id As DriverId,
		a.FirstName As DriverFirstName,
		a.LastName As DriverLastName,
		u.DriverUsername,
		m.FleetName As CurrentHub,
		f.Name As ShiftHub,
		m.OnlineUTC As OnlineUTC,
		m.OfflineUTC As OfflineUTC,
		DATEADD(hour,@UTCOffset,m.OnlineUTC) 'OnlineLocalTime',
		DATEADD(hour,@UTCOffset,m.OfflineUTC) 'OfflineLocalTime'
	INTO #Worktimes
	FROM Handlers h WITH (NOLOCK)
		INNER JOIN #MatchingFleet m ON h.Id = m.DriverId
		INNER JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = m.FleetId
		LEFT JOIN #Usernames u ON h.Id = u.DriverId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,m.OnlineUTC) >= DATEADD(day,-7,@StartDateLocal) AND
		DATEADD(hour,@UTCOffset,m.OnlineUTC) < DATEADD(day,7,@EndDateLocal)
	ORDER BY
		h.Id,
		m.OnlineUTC;

	WITH OnlineTimeCTE AS
	(
		SELECT
			d.Date As LocalDate,
			d.MilitaryHour AS Hour,
			d.DateHour,
			w.DriverId,
			w.DriverFirstName,
			w.DriverLastName,
			w.DriverUsername,
			w.CurrentHub,
			w.ShiftHub,
			CASE
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, w.OnlineLocalTime),0) AND DATEADD(HH, DATEDIFF(HH, 0, w.OnlineLocalTime),0) = DATEADD(HH, DATEDIFF(HH, 0, w.OfflineLocalTime),0) THEN DATEDIFF(S, w.OnlineLocalTime, w.OfflineLocalTime)
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, w.OnlineLocalTime),0) THEN DATEDIFF(S, w.OnlineLocalTime, DATEADD(HH, 1, d.DateHour))
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, w.OfflineLocalTime),0) THEN DATEDIFF(S, d.DateHour, w.OfflineLocalTime)
				WHEN d.DateHour > DATEADD(HH, DATEDIFF(HH, 0, w.OnlineLocalTime),0) AND d.DateHour < DATEADD(HH, DATEDIFF(HH, 0, w.OfflineLocalTime),0) THEN 3600
				ELSE 0
				END AS OnlineTime
		FROM #Worktimes w
			CROSS  APPLY #DateTime d
	),
	OnlineTimeNullCTE As
	(
		SELECT
			o.DriverId,
			SUM(o.OnlineTime) As SUMOnlineTime
		FROM OnlineTimeCTE o
		GROUP BY o.DriverId
	)
	SELECT
		o.DriverId,
		MAX(o.DriverFirstName) As DriverFirstName,
		MAX(o.DriverLastName) As DriverLastName,
		MAX(o.DriverUsername) As DriverUsername,
		MAX(o.CurrentHub) As CurrentHub,
		MAX(o.ShiftHub) As ShiftHub,
		MAX(o.LocalDate) As LocalDate,
		MAX(o.Hour) As LocalHour,
		o.DateHour As LocalDateHour,
		(SELECT COUNT(*)
			FROM #Jobs t
			WHERE
			t.CompletedLocal >= o.DateHour AND
			t.AcceptedLocal < DATEADD(hh,1,o.DateHour) AND
			t.HandlerId = o.DriverId) As JobsAcceptedCount,
		(SELECT COUNT(*)
		FROM #Jobs t
		WHERE
			t.CompletedLocal >= o.DateHour AND
			t.CompletedLocal < DATEADD(hh,1,o.DateHour) AND
			t.HandlerId = o.DriverId) As JobsCompletedCount,
		CAST((SUM(o.OnlineTime)/60.0) As decimal(38,2)) As OnlineTime
	INTO #Output
	FROM OnlineTimeCTE o
		INNER JOIN OnlineTimeNullCTE n ON o.DriverId = n.DriverId
	WHERE
		n.SUMOnlineTime <> 0
	GROUP BY
		o.DriverId,
		o.DateHour
	ORDER BY
		o.DriverId,
		o.DateHour;

	WITH WorkTimeCTE AS
	(
		SELECT
			d.DateHour,
			t.HandlerId,
			CASE
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, t.AcceptedLocal),0) AND DATEADD(HH, DATEDIFF(HH, 0, t.AcceptedLocal),0) = DATEADD(HH, DATEDIFF(HH, 0, t.CompletedLocal),0) THEN DATEDIFF(S, t.AcceptedLocal, t.CompletedLocal)
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, t.AcceptedLocal),0) THEN DATEDIFF(S, t.AcceptedLocal, DATEADD(HH, 1, d.DateHour))
				WHEN d.DateHour = DATEADD(HH, DATEDIFF(HH, 0, t.CompletedLocal),0) THEN DATEDIFF(S, d.DateHour, t.CompletedLocal)
				WHEN d.DateHour > DATEADD(HH, DATEDIFF(HH, 0, t.AcceptedLocal),0) AND d.DateHour < DATEADD(HH, DATEDIFF(HH, 0, t.CompletedLocal),0) THEN 3600
				ELSE 0
				END AS WorkTime
		FROM #JobTimes t
			CROSS  APPLY #DateTime d
	)
	SELECT
		MAX(o.DriverId) As DriverId,
		MAX(o.DriverFirstName) As DriverFirstName,
		MAX(o.DriverLastName) As DriverLastName,
		MAX(o.DriverUsername) As DriverUsername,
		MAX(o.CurrentHub) As CurrentHub,
		MAX(o.ShiftHub) As ShiftHub,
		MAX(o.LocalDate) As LocalDate,
		MAX(o.LocalHour) As LocalHour,
		MAX(o.LocalDateHour) As LocalDateHour,
		CAST((SUM(w.WorkTime)/60.0) As decimal(38,2)) As WorkTime,
		MAX(o.JobsAcceptedCount) As JobsAcceptedCount,
		MAX(o.JobsCompletedCount) As JobsCompletedCount,
		MAX(o.OnlineTime) As OnlineTime
	FROM #Output o
		INNER JOIN WorkTimeCTE w ON o.LocalDateHour = w.DateHour AND o.DriverId = w.HandlerId
	GROUP BY
		o.DriverId,
		o.LocalDateHour
	ORDER BY
		MAX(o.LocalDate),
		o.DriverId,
		o.LocalDateHour;

	/* Drop temp tables created*/
	DROP TABLE
		#DateTime,
		#MatchingFleet,
		#Usernames,
		#Accepted,
		#Jobs,
		#JobTimes,
		#Worktimes,
		#Output;
END

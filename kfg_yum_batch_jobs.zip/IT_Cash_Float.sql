/* KFG Cash Float Report - Sep 25, 2019
Purpose: A query to pull a cash floats for KFG
+ adding cash float info, fleet info, driver info, store user that gave cash float info */
BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of CashTransactions table
	   filtered by Org and DateTime (based on declared variables) and Cash Transaction Type = 4 (Cash Outlay)*/
	SET @InitialCount =
	(
	SELECT COUNT(*)
	FROM CashTransactions ct WITH (NOLOCK)
		LEFT JOIN CashAccountHandlers cah WITH (NOLOCK) ON cah.CashAccountId = ct.ReceivedAccountId
		LEFT JOIN Handlers h WITH (NOLOCK) ON h.Id =  cah.HandlerId
		LEFT JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,ct.DateTime) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,ct.DateTime) < @EndDateLocal AND
		ct.Type = 4 /* Enum for "Cash Outlay" transaction type */
	);

	/* Query CashTransactions table
	   with joins to CashAccountHandlers, CashTransactionAudits, Org, HandlerFleets, and other tables
	   for cash float info, fleet info, driver info, store user that gave cash float info
	   filtered by Org and DateTime (based on declared variables) and "Cash Outlay" transaction type
	   into #Output temp table*/
	SELECT
		ct.Id As FloatId,
		cdt.CashDropId,
		f.Id As HubId,
		CONCAT(au.FirstName,' ',au.LastName) As StoreUser,
		au.Email As StoreEmail,
		h.Id As DriverId,
		CAST(DATEADD(hour,@UTCOffset,ct.DateTime) as varchar) 'Date',
		ct.ReceivedAmount As Amount
	INTO #Output
	FROM CashTransactions ct WITH (NOLOCK)
		LEFT JOIN CashDropTransactions cdt WITH (NOLOCK) ON cdt.CashTransactionId = ct.Id
		LEFT JOIN CashAccountHandlers cah WITH (NOLOCK) ON cah.CashAccountId = ct.ReceivedAccountId
		LEFT JOIN Handlers h WITH (NOLOCK) ON h.Id =  cah.HandlerId
		LEFT JOIN HandlerFleets hf WITH (NOLOCK) ON hf.HandlerId = h.Id
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = hf.FleetId
		LEFT JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
		LEFT JOIN CashTransactionAudits cta WITH (NOLOCK) ON cta.CashTransactionId = ct.Id  /* this table provides the user account info for cash floats and drops */
		LEFT JOIN Accounts au WITH (NOLOCK) ON au.Id = cta.AccountId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,ct.DateTime) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,ct.DateTime) < @EndDateLocal AND
		ct.Type = 4; /* Enum for "Cash Outlay" transaction type */

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o ORDER BY o.FloatId;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Output;
END

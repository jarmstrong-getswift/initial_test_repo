/* KFG Cash Received Orders Report - Sep 25, 2019
Purpose: A query of orders associated with a set of cash received transactions (cash drop / cash settlements) for KFG
+ adding CashDropId, GetSwift Job Id, and SDM Order ID */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group';

	/* Query CashDrop table
	   with joins to Merchants Org tables
	   for CashDrop Ids
	   filtered by Org and Datetime (based on declared variables)
	   into #CashDropId temp table*/
	SELECT
		cd.Id As CashDropId
	INTO #CashDropId
	FROM CashDrops cd WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON cd.MerchantId = m.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,cd.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,cd.Created) < @EndDateLocal;

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract1, CashTransactionIncentives, TransportJobIncentives, CashDropTransactions and other tables
	   for the Job Id, CashDropID for each incentive
	   filtered by Org (and limited by join to #CashDropId)
	   into #Incentive temp table*/
	SELECT
		t.Id As iGetSwiftId,
		cdt.CashDropId As iCashDropId
	INTO #Incentive
	FROM CashTransactions ct WITH (NOLOCK)
		 INNER JOIN CashTransactionIncentives cti WITH (NOLOCK) ON cti.CashTransactionId = ct.Id
		 INNER JOIN TransportJobIncentives tji WITH (NOLOCK) ON cti.TransportJobIncentivesId = tji.Id
		 INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Identifier = tji.TransportJobId
		 INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
		 INNER JOIN #CashDropId c ON c.CashDropId = cdt.CashDropId
	WHERE
		ct.Type = 6
	ORDER BY
		t.Id;

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract, CashTransactionTransportJobs, CashDropTransactions, and other tables
	   for the Job Id, CashDropID for each "Collect from Customer" transaction
	   filtered by Org (and limited by join to #CashDropId)
	   into #CollectFromCustomer temp table*/
	SELECT
		t.Id As cGetSwiftId,
		cdt.CashDropId As cCashDropId
	INTO #CollectFromCustomer
	FROM CashTransactions ct WITH (NOLOCK)
		INNER JOIN CashTransactionTransportJobs ctj WITH (NOLOCK) ON ctj.CashTransactionId = ct.Id
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = ctj.TransportJobId
		INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
		INNER JOIN #CashDropId c ON c.CashDropId = cdt.CashDropId
	WHERE
		ct.Type = 0
	ORDER BY
		t.Id;

	/* Using CTE, query #CollectFromCustomer temp table
	   and UNION join #Incentives table
	   to combine list of jobs with cash drops for "Collect From Customer" and list of jobs with cash drops for "Incentives"
	   for Job ID, CashDropId
	   grouped by Job ID (so no duplicate entries)
	   into #CashDropList temp table*/
	WITH CashDropCTE (Id, CashDropId) As
		(SELECT c.cGetSwiftId, c.cCashDropId FROM #CollectFromCustomer c
		UNION
		SELECT i.iGetSwiftId, i.iCashDropId FROM #Incentive i
		)
	SELECT
		MAX(c.Id) As Id,
		MAX(c.CashDropId) As CashDropId
	INTO #CashDropList
	FROM CashDropCTE c
	GROUP BY
		c.Id
	ORDER BY
		c.Id;

	/* Query #CashDropList temp table
	   with joins to CashDrops, CashDropTransactions
	   + CashTransactions (only on drop transactions, because CashTransactionAudits table only has records for drop and outlay), and other tables
	   for the CashDropId, GetSwift Job Id, SDM Order Id
	   into #Output temp table*/
	SELECT
		cdl.CashDropId As CashDropId,
		t.Reference As OrderId
	INTO #Output
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN #CashDropList cdl ON cdl.Id = t.Id
	ORDER BY
		cdl.Id;

	/* Return #Output query (can't check for initial vs. final row count)*/
	SELECT * FROM #Output o
	WHERE o.OrderId NOT LIKE 'RM Email'
	ORDER BY o.CashDropId, o.OrderId;

	/* Drop temp tables created*/
	DROP TABLE
		#CashDropId,
		#CollectFromCustomer,
		#Incentive,
		#CashDropList,
		#Output;
END

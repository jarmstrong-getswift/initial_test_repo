/* Abandoned Jobs Report - Sep 23, 2019
Purpose: A query to pull month-to-date Organization-level Abandoned Jobs report for KFG
+ adding Abandoned Job time, notes, and number of times per job */

/* Remove count of rows in export */
BEGIN
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of TransportJobsStageEntries table
	   filtered on Stage = 7 (Abandoned)
	   filtered by Org and DateTime (based on declared variables) */
	SET @InitialCount =
	(
	SELECT COUNT(*)
	FROM TransportJobStageEntries ts WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		ts.Stage = 7
	);

	/* Query TransportJobStageEntries table
	   with joins to TransportJobs and other tables
	   for Abandoned entries
	   filtered by Org and DateTime (based on declared variables) Stage = 7
	   into #Abandon temp table*/
	SELECT
		ts.TransportJobId As Id,
		ts.Created,
		ts.Notes
	INTO #Abandon
	FROM TransportJobStageEntries ts WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		ts.Stage = 7;

	/* Query TransportJobs table
	   with joins to Handlers, Fleets, Accounts, #Accepted, #Abandon and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #TransportJobsExtract temp table*/
	SELECT
		t.Reference As OrderId,
		f.Id As HubId,
		m.Id As StoreId,
		h.Id As DriverId,
		DATEADD(hour,@UTCOffset,ab.Created) 'AbandonedDate',
		ab.Notes As AbandonedDetails
	INTO #TransportJobsExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN #Abandon ab ON ab.Id = t.Id
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = t.FleetId
		LEFT JOIN Handlers h WITH (NOLOCK) ON t.HandlerId = h.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Join 1 intermediary temp tables into final #Output temp table
	 + adding count of abandoned entries per job */
	SELECT
		*,
		COUNT(*) OVER(PARTITION BY t.OrderId) As AbandonedCount
	INTO #Output
	FROM #TransportJobsExtract t;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o
		WHERE o.OrderId NOT LIKE 'RM Email'
		ORDER BY o.AbandonedDate;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Abandon,
		#TransportJobsExtract,
		#Output;
END

import pyodbc
import sys
from pathlib import Path
import datetime
import os
import subprocess

'''seemingly excessive number of connections at the top here currently necessary to account for two different modes of pyodbc connectivity and different databases'''
#the connections below this use freetds nomenclature... this first one here use microsoft odbc driver like below.
#only using freetds on my local mac setup -- everything in prod will use the msodbc connection string like below
#qa server
#server = 'tcp:coreweb-sql-qatwo.kube-dev.getswift.co'
#prod server
server = 'coreweb-enterprise-db.cfypcmdyplvr.eu-west-1.rds.amazonaws.com'

#qa database
#database='qa2'
#prod database
database = 'SWIFT'

#qa username/pass
#username = 'qa2-sql-account'
#password = 'ZDqxsYxMBRRYirjn2G6LRfm'

#prod username/pass
username = 'uat-sql-readonly'
password = 'Sh4Je($9x*R&Q+<JPon2'

conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
crsr = conn.cursor()
#===================================================#
#this connection is to the archive db sandbox where we can create tables
#conn = pyodbc.connect('DSN=MYMSSQL;UID=sqlreadonly;Database=archive;PWD=4LgXJfNKIcUG08BgPIvD')
#crsr = conn.cursor()

#CURRENTLY USING
#this connection is to enterprise "QA" sandbox that we can beat up with testing
#conn = pyodbc.connect('DSN=QAMSSQL;UID=qa2-sql-account;PWD=ZDqxsYxMBRRYirjn2G6LRfm')
#crsr = conn.cursor()

#this is enterprise production
#conn = pyodbc.connect('DSN=EPMSSQL;DATABASE=Swift;UID=uat-sql-readonly;PWD=Sh4Je($9x*R&Q+<JPon2')
#crsr = conn.cursor()

d=datetime.datetime.now()

'''main run time variables'''
code_path="./"
sql_path="./"
metadata_file = "kfg_job_metadata.txt"

utcdate = (d.strftime("%Y-%m-%d"))
utcdatetime = (d.strftime("%Y-%m-%d %H%M%S"))
file_suffix="_" + str(utcdatetime.replace(' ','_')) + ".csv"
ftp_path_dir_suffix = str(utcdatetime.replace(' ','_'))
''' running on docker, the "local" input is what's inside the docker container.'''
''' create a new directory that is the timestamp of each run '''
local_output = "/data/" + ftp_path_dir_suffix + "/"


''''when testing on local box, create local directory to spool files to e.g.'''
#local_output = "/Users/jarmstrong/Downloads/17_reports/testdir/" + ftp_path_dir_suffix + "/"

'''remote directory generated files are put'''
#
#the following is for test vagrant server -- works for sftp
#remote_output = "/home/vagrant/testdir/"

'''function to process sql for log insert/update only'''
'''we don't try to log errors or db output to the DashboardReportLog table here because if we honestly fail when updating a log, it implies much larger issues...'''
def try_sql_commit_iu(sql_in):
    try:
        crsr.execute(sql_in)
    except pyodbc.Error as err:
        dberror = err.args[1]
        conn.rollback()
    else:
        conn.commit()

'''function that does main processing of sql files -- execute cursor, update db with error as necessary'''
def try_sql_commit_main(sql_in):
    try:
        crsr.execute(sql_in)
    except pyodbc.Error as err:
        '''we trim out single ticks in error message to avoid issues when inserting into db column'''
        dberror = err.args[1].replace('\'','')
        #log_insert_update('UPDATE','FAILURE', dberror)
        rows=""
        conn.rollback()
    else:
        rows = crsr.fetchall()
        #log_insert_update('UPDATE','SUCCESS', '')
        conn.commit()
    return rows

'''function that performs insert/update into log table'''
def log_insert_update(insert_update, report_status, dberror):

    '''yes, using globals is generally bad practice but this was the most minimalist/elegant way I could find to do it...'''
    global record_id
    utcd=datetime.datetime.now()
    utcdate = (utcd.strftime("%Y-%m-%d %H:%M:%S"))

    if insert_update == 'INSERT':

        sql_log = "INSERT INTO DashboardReportLog (ReportName, FileName, ReportStartTime, ReportEndTime, ReportStatus) VALUES \
        (" + "'" + sql_file + "','" + sql_file + file_suffix + "','" + str(utcdate) + "','" + str(utcdate) + "','" + report_status + "');"

        try_sql_commit_iu(sql_log)

        '''preserve the identity value of the last insert for subsequent update of SUCCESS or FAILURE depending on status of main sql executed'''
        record_id = crsr.execute('SELECT @@IDENTITY AS id;').fetchone()[0]

    elif insert_update == 'UPDATE':

        sql_log = "UPDATE DashboardReportLog SET ReportStatus = '" + report_status + "', ReportEndTime = '" + str(utcdate) + "', Dberror = '" + dberror + "', RowCount = " + str(row_count) +  " WHERE Id = " + str(record_id)
        try_sql_commit_iu(sql_log)

def create_append_consolidated_file (read_write, print_header, file_output_name_in, file_description_in, row_count_in, file_columns_in, consolidated_columns_in, consolidated_file_in, consolidated_path):
    f = open(consolidated_path, read_write)
    sys.stdout = f
    '''print file header'''
    if print_header is True:
        print (consolidated_columns_in)
    print ('"' + file_output_name_in + '"', file_description_in, '"' + str(row_count_in) + '"', '"' + str(len(file_columns_in.split(','))) + '"', sep=',')
    sys.stdout = orig_stdout
    f.close()

def prep_consolidated_file(file_output_name_in, file_description_in, row_count_in, file_columns_in, consolidated_columns_in, consolidated_file_in):

    '''No Consolidated file prepared for Yum! -- both reports have "Report Consolidated Information" as their first three tokens in nomenclature'''
    report_name ="Report Consolidated Information"

    '''the only difference between the "IT" and "CC" consolidated files is the CC one has a timestamp in the filename, the IT one doesn't.'''
    '''A more intuitive nomenclature would have been preferred, but not going to rock the boat here'''
    print (file_output_name_in, file_description_in, row_count_in, file_columns_in, consolidated_columns_in, consolidated_file_in)

    '''check to see if Report Consolidated Information_YYYY-mm-dd exists; if not, create file with header and add first line; if exists, just add next element without header'''
    '''Again -- the only difference between the "IT" and "CC" Report Consolidated files is that one has a timestamp suffix, the other does not'''
    ''' "w+" is the python filehandle to create and open a new file if it doesn't exist; "a" is to append to an existing file '''
    ''' this implicitly skips Yum!, since it requires no consolidated file '''
    if consolidated_file_in.strip() == (report_name + "_YYYY-mm-dd"):
        consolidated_path = (local_output + report_name +"_" + utcdate + ".csv")
    elif consolidated_file_in.strip() == (report_name + "_YYYY-mm-dd_HHMMSS"):
        consolidated_path = (local_output + report_name + "_" + str(utcdatetime.replace(' ','_')) + ".csv")
    else:
        return None

    if os.path.exists(consolidated_path) is False:
        create_append_consolidated_file('w+', True, file_output_name_in, file_description_in, row_count_in, file_columns_in, consolidated_columns_in, consolidated_file_in, consolidated_path)
    elif os.path.exists(consolidated_path) is True:
        create_append_consolidated_file('a', False, file_output_name_in, file_description_in, row_count_in, file_columns_in, consolidated_columns_in, consolidated_file_in, consolidated_path)

def ftps_files(directory_in, kfg_or_yum):

    if kfg_or_yum == "KFG":
        ftp_username="cdmftp@homaizi.com"
        ftp_password="Sdm@kfg2019"
        ftp_server="cdmftp.koutfood.com"
        directory_out="./GetSwift/test"
    elif kfg_or_yum == "YUM":
        ftp_username="XPINTELLT"
        ftp_password="m30RIch=QiHoho"
        ftp_server="sftproots.yum.com"
        directory_out="./PH_MENA/GetSwift"
    else:
        return None

    #we are using a subprocess instead of FTP_TLS due to a serious issue with ftplib.FTP_TLS -- see https://stackoverflow.com/questions/12164470/python-ftp-implicit-tls-connection-issue
    subprocess.call([code_path+"ftps_upload.sh", ftp_username, ftp_password, ftp_server, directory_in, directory_out, kfg_or_yum])

'''create initial data directory [timestamp subdirectory] to store generated files in'''
'''it was necessary to create the directory with 777 privileges, then restore the original privileges with umask'''
def create_data_dir(pathname):
    original_umask = os.umask(0)
    os.makedirs(pathname, mode=0o777, exist_ok=True)
    os.umask(original_umask)

'''begin main data processing'''
create_data_dir(local_output)

with open (code_path + metadata_file, "r") as myfile:
   metadata=myfile.readlines()

for metadatas in metadata:
   metadata_list = metadatas.split(":")
   sql_file = metadata_list[0]
   file_columns = metadata_list[1]
   file_output_name = metadata_list[2]
   file_description = metadata_list[3]
   consolidated_columns = metadata_list[4]
   consolidated_file = metadata_list[5]
   field_delimiter = metadata_list[6]

   row_count = 0

   '''make initial log entry for each SQL file at inception of data extract'''
   #log_insert_update('INSERT','RUNNING','')

   '''ingest sql files in sql_path directory and execute'''
   sql = Path(sql_path + sql_file + '.sql').read_text()

   '''get data from sql files, apply requisite delimiter, remove whitespace to account for CR's in free form text fields, and close file'''
   rows = try_sql_commit_main(sql)

   orig_stdout = sys.stdout
   print ("open is", local_output + file_output_name + file_suffix)
   f = open(local_output + file_output_name + file_suffix, 'w+')
   sys.stdout = f

   '''print file header in output file before first pass'''
   print (file_columns)

   '''generate the actual data for the report and parse into csv'''
   for row in rows:
       output_line = (field_delimiter.join('\"' + str(x) + '\"' for x in row))
       output_line = output_line.replace('\n','').replace('\r','')
       output_line = output_line.replace('\"None\"','\"\"')

       print (output_line)
       row_count += 1

   sys.stdout = orig_stdout
   f.close()

   '''after data retrieved, prepare the "consolidated" files which contain metadata (file name, file description, row count, etc)'''
   prep_consolidated_file(file_output_name, file_description, row_count, file_columns, consolidated_columns, consolidated_file)

crsr.close()
conn.close()

print ("local_output is", local_output)
ftps_files(local_output, 'KFG')
ftps_files(local_output, 'YUM')

# error/logging table ddl
#create table DashboardReportLog
#(
#    Id  int identity
#        constraint PK_KfgRptLog
#        primary key,
#    ReportName      varchar(100),
#    FileName        varchar(100),
#    ReportStartTime datetime,
#    ReportEndTime   datetime,
#    ReportStatus    varchar(100),
#    Row_Count        int,
#    Dberror varchar(1000)
#);

/* KFG Driver Cash Management Report - Feb 2, 2020
Purpose: A query of orders associated with a set of cash received transactions (cash drop / cash settlements) for KFG
+ adding CashDropId, GetSwift Job Id, and SDM Order ID */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group';

	/* Query CashDrop table
	   with joins to Merchants Org tables
	   for CashDrop Ids
	   filtered by Org and Datetime (based on declared variables)
	   into #CashDropId temp table*/
	SELECT
		cd.Id As CashDropId
	INTO #CashDropId
	FROM CashDrops cd WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON cd.MerchantId = m.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,cd.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,cd.Created) < @EndDateLocal;

	/* Create #OrderStageEnum temp table
	   to convert Driver Activity Enum to display text*/
	CREATE TABLE #OrderStageEnum (
		Id INT,
		DisplayText VARCHAR(MAX)
	);

	INSERT INTO #OrderStageEnum
	VALUES	(0,'Received'),
			(1,'Accepted'),
			(3,'En Route'),
			(5,'Completed'),
			(6,'Cancelled'),
			(7,'Abandoned');

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract1, CashTransactionIncentives, TransportJobIncentives, CashDropTransactions and other tables
	   for the Job Id, CashDropID for each incentive
	   filtered by Org (and limited by join to #CashDropId)
	   into #Incentive temp table*/
	SELECT
		t.Id As iGetSwiftId,
		cdt.CashDropId As iCashDropId,
		ct.PaidAmount,
		ct.ReceivedAmount
	INTO #Incentive
	FROM CashTransactions ct WITH (NOLOCK)
		 INNER JOIN CashTransactionIncentives cti WITH (NOLOCK) ON cti.CashTransactionId = ct.Id
		 INNER JOIN TransportJobIncentives tji WITH (NOLOCK) ON cti.TransportJobIncentivesId = tji.Id
		 INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Identifier = tji.TransportJobId
		 INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
		 INNER JOIN #CashDropId c ON c.CashDropId = cdt.CashDropId
	WHERE
		ct.Type = 6;

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract, CashTransactionTransportJobs, CashDropTransactions, and other tables
	   for the Job Id, CashDropID for each "Collect from Customer" transaction
	   filtered by Org (and limited by join to #CashDropId)
	   into #CollectFromCustomer temp table*/
	SELECT
		t.Id As cGetSwiftId,
		cdt.CashDropId As cCashDropId,
		ct.PaidAmount,
		ct.ReceivedAmount
	INTO #CollectFromCustomer
	FROM CashTransactions ct WITH (NOLOCK)
		INNER JOIN CashTransactionTransportJobs ctj WITH (NOLOCK) ON ctj.CashTransactionId = ct.Id
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = ctj.TransportJobId
		INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
		INNER JOIN #CashDropId c ON c.CashDropId = cdt.CashDropId
	WHERE
		ct.Type = 0;

	/* Using CTE, query #CollectFromCustomer temp table
	   and UNION join #Incentives table
	   to combine list of jobs with cash drops for "Collect From Customer" and list of jobs with cash drops for "Incentives"
	   for Job ID, CashDropId
	   grouped by Job ID (so no duplicate entries)
	   into #CashDropList temp table*/
	WITH CashDropCTE (Id, CashDropId, PaidAmount, ReceivedAmount) As
		(SELECT c.cGetSwiftId, c.cCashDropId, c.PaidAmount, c.ReceivedAmount FROM #CollectFromCustomer c
		UNION
		SELECT i.iGetSwiftId, i.iCashDropId, i.PaidAmount, i.ReceivedAmount FROM #Incentive i
		)
	SELECT
		MAX(c.Id) As Id,
		MAX(c.CashDropId) As CashDropId,
		MAX(c.PaidAmount) As PaidAmount1,
		MAX(c.ReceivedAmount) As ReceivedAmount1
	INTO #CashDropList
	FROM CashDropCTE c
	GROUP BY
		c.Id;

	/* Query CashTransactions table
	   with joins to CashDropTransactions, CashDrops, CashAccountHandlers, CashTransactionAudits, Org, HandlerFleets, and other tables
	   for cash drop + variance info, fleet info, driver info, store user that settled cash drop info
	   filtered by Org and DateTime (based on declared variables)
	   into #Output temp table*/
	SELECT
		cdt.CashDropId As CashDropId,
		h.Id As DriverId,
		DATEADD(hour,@UTCOffset,cd.Created) 'CashDropDate',
		ct.FleetId As HubId,
		CONCAT(au.FirstName,' ',au.LastName) As StoreUser,
		au.Email As StoreEmail,
		cd.Variance As CashDropVariance,
		cd.Notes As CashDropVarianceNotes,
		ct.ReceivedAmount As CashDropAmount
	INTO #CashDrop
	FROM CashTransactions ct WITH (NOLOCK)
		INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON cdt.CashTransactionId = ct.Id
		INNER JOIN CashDrops cd WITH (NOLOCK) ON cd.Id = cdt.CashDropId
		INNER JOIN Merchants m WITH (NOLOCK) ON cd.MerchantId = m.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN CashAccountHandlers cah WITH (NOLOCK) ON cah.CashAccountId = ct.PaidAccountId
		LEFT JOIN Handlers h WITH (NOLOCK) ON h.Id =  cah.HandlerId
		LEFT JOIN CashTransactionAudits cta WITH (NOLOCK) ON cta.CashTransactionId = ct.Id
		LEFT JOIN Accounts au WITH (NOLOCK) ON au.Id = cta.AccountId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,cd.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,cd.Created) < @EndDateLocal AND
		ct.Type = 1 /* Enum for "Return to Store" transaction type */;

	/* Query #CashDropList temp table
	   with joins to CashDrops, CashDropTransactions
	   + CashTransactions (only on drop transactions, because CashTransactionAudits table only has records for drop and outlay), and other tables
	   for the CashDropId, GetSwift Job Id, SDM Order Id
	   into #Output temp table*/
	SELECT
		cdl.CashDropId As cCashDropId,
		cdl.Id As GetSwiftId,
		t.Reference As OrderId,
		e.DisplayText As OrderStatus
	INTO #DropOrders
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN #CashDropList cdl ON cdl.Id = t.Id
		INNER JOIN #OrderStageEnum e ON e.Id = t.CurrentStage;

	/* Query TransportJobMetadatas table
	   with joins to TransportJobs and other tables
	   for the Total Price, NCR Payment, Cash To Collect information for each job
	   filtered by Org and DateTime (based on declared variables)
	   into #JobMetadata temp table*/
	SELECT
		tm.TransportJobId As GetSwiftId,
		CAST(MAX(CASE WHEN tm.JobMetadata = 9 THEN tm.Value ELSE NULL END) As decimal(19,4)) As CashToCollect
	INTO #JobMetadata
	FROM TransportJobMetadatas tm WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = tm.TransportJobId
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		(tm.JobMetadata IN (9))
	GROUP BY tm.TransportJobId;

	/* Query TransportJobs table
	   with joins to #MetadataExtract and other tables
	   for the Price, NCR Payment, Cash To Collect, Incentive for each job
	   and calc Subtotal price, spilt out NCR Payment JSON
	   filtered by Org and DateTime (based on declared variables)
	   into #Price temp table*/
	SELECT
		t.Id As pGetSwiftId,
		DATEFROMPARTS(YEAR(DATEADD(hour,@UTCOffset-6,t.Created)),MONTH(DATEADD(hour,@UTCOffset-6,t.Created)),DAY(DATEADD(hour,@UTCOffset-6,t.Created))) As 'OrderDOB',
		t.Created As OrderCreatedDate,
		COALESCE(jm.CashToCollect, 0) As CashToCollect1,
		COALESCE(i.Amount, 0) As IncentiveAmount
	INTO #Price
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN #JobMetadata jm ON jm.GetSwiftId = t.Id
		LEFT JOIN TransportJobIncentives ti WITH (NOLOCK) ON t.Identifier = ti.TransportJobId
		LEFT JOIN Incentives i WITH (NOLOCK) ON ti.IncentiveId = i.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Join 4 intermediary temp tables into final #Output temp table */
	SELECT 
		*
	INTO #Temp FROM #DropOrders do
		LEFT JOIN #CashDrop cd ON do.cCashDropId = cd.CashDropId
		LEFT JOIN #Price p ON do.GetSwiftId = p.pGetSwiftId;

	/* Add additional fields */
	SELECT 
		t.DriverId,
		t.CashDropId,
		t.OrderId,
		t.OrderDOB,
		t.OrderCreatedDate,
		t.OrderStatus,
		t.CashDropDate,
		t.HubId,
		t.StoreUser,
		t.StoreEmail,
		CASE
		WHEN t.OrderStatus = 'Cancelled' THEN 0
		ELSE t.CashToCollect1
		END As CashToCollect,
		t.IncentiveAmount,
		t.CashDropVariance,
		t.CashDropVarianceNotes,
		t.CashDropAmount
	INTO #Output FROM #Temp t

	/* Return #Output query (can't check for initial vs. final row count)*/
	SELECT
		*,
		o.CashToCollect - o.IncentiveAmount As CashMinusIncentive
	FROM #Output o
	WHERE o.OrderId NOT LIKE 'RM Email'
	ORDER BY o.DriverId, o.CashDropId, o.OrderId;

	/* Drop temp tables created*/
	DROP TABLE
		#CashDropId,
		#CollectFromCustomer,
		#Incentive,
		#CashDropList,
		#CashDrop,
		#DropOrders,
		#JobMetadata,
		#Price,
		#OrderStageEnum,
		#Temp,
		#Output;
END

/* KFG Driver Report - Sep 25, 2019
Purpose: A query to pull a list of drivers (Handlers) for KFG
+ adding driver + account info, UDF driver metadata info, driver fleet info */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE	@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of Handlers table
	   filtered by Org */
	SET @InitialCount = 
	(
	SELECT COUNT(*)
	FROM Handlers h WITH (NOLOCK)
		FULL OUTER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE 
		o.Name = @OrgName
	);

	/* Create #ModeOfTransport temp table
	   to convert Mode of Transport to display text*/
	CREATE TABLE #ModeofTransport (
		Id INT,
		DisplayText VARCHAR(MAX)
	);

	INSERT INTO #ModeofTransport
	VALUES	(0,'Car'),
			(1,'Walker'),
			(2,'Subway'),
			(3,'Bicycle'),
			(4,'Uber'),
			(5,'Truck'),
			(6,'Taxi'),
			(7,'Van'),
			(8,'Drone'),
			(9,'Motorbike'),
			(10,'Scooter');

	/* Query Accounts table
	   with joins to AccountUsernames and other tables
	   for the Username of account without email (no duplicates)
	   filtered by Org and DateTime (based on declared variables) 
	   into #Usernames temp table*/
	SELECT
		MAX(h.Id) As DriverId,
		MAX(au.Username) As DriverUsername
	INTO #Usernames
	FROM Accounts a WITH (NOLOCK)
		INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
		INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE 
		o.Name = @OrgName AND
		au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
	GROUP BY
		a.Id
	ORDER BY
		a.Id;

	/* Query Handlers table
	   with joins to Accounts, Org, HandlerFleets, UDFHandlerValue, UDFValues and other tables
	   for the driver + account info, UDF driver metadata info, driver fleet info
	   filtered by Org
	   into #Output temp table*/
	SELECT
		h.Id As DriverId,
		u.DriverUsername As DriverUsername,
		a.FirstName As DriverFirstName,
		a.LastName As DriverLastName,
		a.Email As DriverEmail,
		(CASE WHEN a.Roles = 16 THEN 'FALSE' ELSE 'TRUE' END) As DriverActive,
		uvd.DisplayName As DriverType,
		UPPER(uhi.Data) As IncentiveEligibility,
		f.Id As DriverHubId,
		a.CreatedDate As JoinedGetSwiftDate,
		a.Phone As DriverPhoneNumber,
		mt.DisplayText As VehicleType
	INTO #Output
	FROM Handlers h WITH (NOLOCK)
		INNER JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
		LEFT JOIN #ModeofTransport mt ON mt.Id = h.ModeOfTransport
		LEFT JOIN #Usernames u ON u.DriverId = h.Id
		LEFT JOIN HandlerFleets hf WITH (NOLOCK) ON hf.HandlerId = h.Id
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = hf.FleetId AND f.Deleted = 0
		LEFT JOIN UDFHandlerValues uhi WITH (NOLOCK) ON uhi.HandlerId = a.Identifier AND uhi.UDFId = '333BBD5D-A36D-4794-80DC-D72AB40A8180' /* UDF for Incentive Eligible */
		LEFT JOIN UDFHandlerValues uhd WITH (NOLOCK) ON uhd.HandlerId = a.Identifier AND uhd.UDFId = '9458F1D2-880A-4779-987B-4F79A2304520' /* UDF for Type of Driver */
		LEFT JOIN UDFValues uvd WITH (NOLOCK) ON uvd.Id = uhd.UDFValuesId
	WHERE 
		o.Name = @OrgName;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount = 
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount 
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount 
		SELECT * FROM #Output o 
		ORDER BY o.DriverId;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#ModeofTransport,
		#Usernames,
		#Output;
END

/* Driver Work Times - Sep 3, 2019
Purpose: A query to pull month-to-date Organization-level Driver Work Times report for KFG
+ with UTC/Local times, Current Hub & Shift Hub, and # of jobs completed during shift*/

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @UTCOffset INT = 3; /* Turn UTC time into local time*/
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of "Online" activity in HandlerActivityLogEntries table
	   filtered by Org and DateTime (based on declared variables) */
	SET @InitialCount = (
		SELECT COUNT(*)
		FROM
			(SELECT
					hl.HandlerId As DriverId,
					OnlineUTC =
						CASE WHEN hl.Activity = 0 THEN hl.Created END,
					OfflineUTC =
						CASE
						/* If the next Event by EventTime is a logout */
						WHEN LEAD(hl.Activity, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created) = 1
						/* Then we pick up the corresponding EventTime */
						THEN LEAD(hl.Created, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created)
						/* Otherwise logout time will be set to NULL */
						END,
					hl.Activity
				FROM HandlerActivityLogEntries hl WITH (NOLOCK)
					INNER JOIN Handlers h WITH (NOLOCK) ON h.Id = hl.HandlerId
					INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
				WHERE
					o.Name = @OrgName AND
					DATEADD(hour,@UTCOffset,hl.Created) >= DATEADD(day,-7,@StartDateLocal) AND
					DATEADD(hour,@UTCOffset,hl.Created) < DATEADD(day,7,@EndDateLocal) AND
					(hl.Activity = 0 OR hl.Activity = 1)
			) h
		WHERE
			h.Activity = 0 AND
			h.OfflineUTC IS NOT NULL AND
			DATEADD(hour,@UTCOffset,h.OnlineUTC) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,h.OnlineUTC) < @EndDateLocal
	);

	/* Query TransportJobs table
	   for the ID, CompletedUTC time, and Handler ID of jobs
	   filtered by Org and DateTime (based on declared variables)
	   into #Jobs temp table*/
	SELECT
		t.Id,
		t.HandlerId,
		t.FleetId,
		t.Created,
		t.OrderOnWay,
		t.Completed
	INTO #Jobs
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Completed) >= DATEADD(day,-7,@StartDateLocal) AND
		DATEADD(hour,@UTCOffset,t.Completed) < DATEADD(day,7,@EndDateLocal) AND
		t.HandlerId IS NOT NULL;

	/* Query #DriverOnline table
	   with sub-query for Fleet Name that driver was associated with at that time AND
	   with sub-query for Offline Time associated with the Online time
	   filtered by Org and DateTime (based on declared variables)
	   into #MatchingFleet temp table*/
	WITH HandlerLogsCTE As
		(
			SELECT
				hl.HandlerId As DriverId,
				f.Name As FleetName,
				OnlineUTC =
					CASE WHEN hl.Activity = 0 THEN hl.Created END,
				OfflineUTC =
					CASE
					/* If the next Event by EventTime is a logout */
					WHEN LEAD(hl.Activity, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created) = 1
					/* Then we pick up the corresponding EventTime */
					THEN LEAD(hl.Created, 1) OVER (PARTITION BY hl.HandlerId ORDER BY hl.Created)
					/* Otherwise logout time will be set to NULL */
					END,
				hl.Activity
			FROM HandlerActivityLogEntries hl WITH (NOLOCK)
				INNER JOIN Handlers h WITH (NOLOCK) ON h.Id = hl.HandlerId
				INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
				LEFT JOIN HandlerFleets hf WITH (NOLOCK) ON h.Id = hf.HandlerId
				LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = hf.FleetId
			WHERE
				o.Name = @OrgName AND
				DATEADD(hour,@UTCOffset,hl.Created) >= DATEADD(day,-7,@StartDateLocal) AND
				DATEADD(hour,@UTCOffset,hl.Created) < DATEADD(day,7,@EndDateLocal) AND
				(hl.Activity = 0 OR hl.Activity = 1)
		)
	SELECT
		*,
		FleetId1 =
			(SELECT TOP 1 t.FleetId
			FROM #Jobs t
			WHERE
				h.OnlineUTC <= t.OrderOnWay AND   /* The first job for that driver after going online*/
				t.HandlerId = h.DriverId
			ORDER BY t.Created ASC),
		FleetId2 =
			(SELECT t.FleetId
			FROM #Jobs t
			WHERE
				h.OnlineUTC <= t.OrderOnWay AND   /* The second job for that driver after going online*/
				t.HandlerId = h.DriverId
			ORDER BY t.Created ASC
			OFFSET 1 ROWS
			FETCH NEXT 1 ROWS ONLY),
		FleetId = CAST(NULL AS VARCHAR(MAX))
	INTO #MatchingFleet
	FROM HandlerLogsCTE h
	WHERE
		h.Activity = 0 AND
		h.OfflineUTC IS NOT NULL
	ORDER BY
		h.DriverId,
		h.OnlineUTC;

	UPDATE #MatchingFleet SET FleetId = COALESCE(FleetId1, FleetId2); /* Combine FleetId1 and FleetId2*/

	/* Query Accounts table
	   with joins to AccountUsernames and other tables
	   for the Username of account without email (no duplicates)
	   filtered by Org and DateTime (based on declared variables)
	   into #Usernames temp table*/
	SELECT
		MAX(h.Id) As DriverId,
		MAX(au.Username) As DriverUsername
	INTO #Usernames
	FROM Accounts a WITH (NOLOCK)
		INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
		INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE
		o.Name = @OrgName AND
		au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
	GROUP BY
		a.Id
	ORDER BY
		a.Id;

	/* Query Handler table
	   with joins to #MatchingFleet and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #Final temp table*/
	SELECT
		h.Id As DriverId,
		a.FirstName As DriverFirstName,
		a.LastName As DriverLastName,
		u.DriverUsername,
		m.FleetName As CurrentHub,
		f.Name As ShiftHub,
		m.OnlineUTC As OnlineUTC,
		m.OfflineUTC As OfflineUTC,
		OnlineLocalTime =
			DATEADD(hour,@UTCOffset,m.OnlineUTC),
		OfflineLocalTime =
			DATEADD(hour,@UTCOffset,m.OfflineUTC),
		JobsCompletedCount =
			(
			SELECT COUNT(*)
			FROM #Jobs t
			WHERE
				t.Completed >= m.OnlineUTC AND
				t.Completed < m.OfflineUTC AND
				t.HandlerId = h.Id
			),
		ShiftId =
			CAST(h.Id As nvarchar(20)) + '_' + CONVERT(nvarchar,DATEADD(hour,@UTCOffset,m.OnlineUTC),126)
	INTO #Final
	FROM Handlers h
		INNER JOIN #MatchingFleet m ON h.Id = m.DriverId
		INNER JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = m.FleetId
		LEFT JOIN #Usernames u ON h.Id = u.DriverId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,m.OnlineUTC) >= DATEADD(day,-7,@StartDateLocal) AND
		DATEADD(hour,@UTCOffset,m.OnlineUTC) < DATEADD(day,7,@EndDateLocal)
	ORDER BY
		h.Id,
		m.OnlineUTC;

	/* Query #Final table
	   with sub-query for count of completed jobs for that driver during shift
	   and return end results*/
	SELECT *
	INTO #Output
	FROM #Final f
	WHERE
		f.OnlineLocalTime >= @StartDateLocal AND
		f.OnlineLocalTime < @EndDateLocal
	ORDER BY
		f.DriverId,
		f.OnlineUTC;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT *
		FROM #Output o
		ORDER BY
			o.DriverId,
			o.OnlineUTC;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Jobs,
		#MatchingFleet,
		#Usernames,
		#Final,
		#Output;
END

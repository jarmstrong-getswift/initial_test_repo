/* KFG Orders Report - Sep 26, 2019
Purpose: A query to pull month-to-date Organization-level Jobs report for KFG
+ adding Cash Management fields (CashCollected, Cash Drop, Incentives, etc.)*/

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = SMALLDATETIMEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE()), 06, 00), /* This will give today's datetime at 06:00 Kuwait time */
			@UTCOffset INT = 3, /* Turn UTC time into local time*/
			@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of TransportJobs table
	   filtered by Org and DateTime (based on declared variables) */
	SET @InitialCount =
	(
	SELECT COUNT(*)
	FROM TransportJobs t WITH (NOLOCK)
		FULL OUTER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		FULL OUTER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	);

	/* Create #OrderStageEnum temp table
	   to convert Driver Activity Enum to display text*/
	CREATE TABLE #OrderStageEnum (
		Id INT,
		DisplayText VARCHAR(MAX)
	);

	INSERT INTO #OrderStageEnum
	VALUES	(0,'Received'),
			(1,'Accepted'),
			(3,'En Route'),
			(5,'Completed'),
			(6,'Cancelled'),
			(7,'Abandoned');

	/* Using CTE, query TransportJobStageEntries table
	   for Accepted entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Accepted temp table*/
	WITH AcceptedCTE (Id, Created, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 1 AND
			ts.Notes NOT LIKE '%at pickup%'
		)
	SELECT *
	INTO #Accepted
	FROM AcceptedCTE ac
	WHERE ac.RowNumber = 1
	ORDER BY ac.Id;

	/* Using CTE, query TransportJobStageEntries table
	   for Abandoned entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Abandon temp table*/
	WITH AbandonCTE (Id, IsAbandon, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			'TRUE' As IsAbandon,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 7
		)
	SELECT *
	INTO #Abandon
	FROM AbandonCTE ab
	WHERE ab.RowNumber = 1
	ORDER BY ab.Id;

	/* Query TransportJobs table
	   with joins to Handlers, Fleets, Accounts, TransportJobLocations and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #TransportJobsExtract1 temp table*/
	SELECT
		t.Id As GetSwiftId,
		t.Identifier,
		t.Reference As OrderId,
		CASE
			WHEN LEFT(t.Source,3) = 'Ncr' THEN 'SDM'
			ELSE 'Manual'
		END As CreationMethod,
		f.Id As HubId,
		CAST(DATEFROMPARTS(YEAR(DATEADD(hour,@UTCOffset-6,t.Created)),MONTH(DATEADD(hour,@UTCOffset-6,t.Created)),DAY(DATEADD(hour,@UTCOffset-6,t.Created))) as varchar) 'OrderDate',
		(CASE WHEN t.AvailableAfter > t.Created THEN 'Future' ELSE 'Now' END) As OrderType,
		m.Id As StoreId,
		CAST(tl.Latitude As varchar(MAX)) + ', ' + CAST(tl.Longitude As varchar(MAX)) As AddressCoordinates,
		CAST(DATEADD(hour,@UTCOffset,t.DropoffTime_LatestTime) as varchar) 'PromiseTime',
		h.Id As DriverId
	INTO #TransportJobsExtract1
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = t.FleetId
		LEFT JOIN Handlers h WITH (NOLOCK) ON t.HandlerId = h.Id
		LEFT JOIN TransportJobLocations tl WITH (NOLOCK) ON t.Id = tl.TransportJobId AND tl.Type = 1 /* Dropoff location filter */
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobs table
	   with joins to #Accepted, #Abandon, FleetConfigEntries, OrgConfigEntries and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #TransportJobsExtract2 temp table*/
	SELECT
		t.Id As tGetSwiftId,
		CAST(DATEADD(hour,@UTCOffset,t.Created) as varchar)  'InitialOrderTime',
		CAST(DATEADD(hour,@UTCOffset,t.OrderProcessed)  as varchar) 'InKitchenTime',
		CAST(DATEADD(hour,@UTCOffset,t.OrderReady)  as varchar) 'ReadyTime',
		CAST(DATEADD(hour,@UTCOffset,ac.Created)  as varchar) 'AcceptedTime',
		CAST(DATEADD(hour,@UTCOffset,t.ArrivedAtPickup)  as varchar) 'AtPickupTime',
		CAST(DATEADD(hour,@UTCOffset,t.OrderOnWay)  as varchar) 'EnRouteTime',
		CAST(DATEADD(hour,@UTCOffset,t.ArrivedAtDropoff)  as varchar) 'AtDestinationTime',
		CAST(DATEADD(hour,@UTCOffset,t.Completed)  as varchar) 'CompletedTime',
		e.DisplayText As [Status],
		(CASE WHEN ab.IsAbandon = 'TRUE' THEN 'TRUE' ELSE 'FALSE' END) As IsAbandon,
		COALESCE(UPPER(fc.ConfigValue), UPPER(oc.ConfigValue)) As AlgoType /* Check Fleet config, if none, then check Org Config */
	INTO #TransportJobsExtract2
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN #OrderStageEnum e ON e.Id = t.CurrentStage
		LEFT JOIN #Accepted ac ON ac.Id = t.Id
		LEFT JOIN #Abandon ab ON ab.Id = t.Id
		LEFT JOIN FleetConfigEntries fc WITH (NOLOCK) ON fc.FleetId = t.FleetId AND fc.MerchantConfigType = 79 /* Routing Algo Type filter */
		LEFT JOIN OrgConfigEntries oc WITH (NOLOCK) ON oc.OrganisationId = o.Id AND oc.MerchantConfigType = 79 /* Routing Algo Type filter */
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query TransportJobMetadatas table
	   with joins to TransportJobs and other tables
	   for the Total Price, NCR Payment, Cash To Collect information for each job
	   filtered by Org and DateTime (based on declared variables)
	   into #JobMetadata temp table*/
	SELECT
		tm.TransportJobId As GetSwiftId,
		CAST(MAX(CASE WHEN tm.JobMetadata = 20 THEN tm.Value ELSE NULL END) As decimal(19,4)) As TotalPrice,
		MAX(CASE WHEN tm.JobMetadata = 21 THEN tm.ValueJson ELSE NULL END) As NcrPayment,
		CAST(MAX(CASE WHEN tm.JobMetadata = 9 THEN tm.Value ELSE NULL END) As decimal(19,4)) As CashToCollect
	INTO #JobMetadata
	FROM TransportJobMetadatas tm WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = tm.TransportJobId
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		(tm.JobMetadata IN (20, 21, 9))
	GROUP BY tm.TransportJobId
	ORDER BY tm.TransportJobId;

	/* Query TransportJobs table
	   with joins to #MetadataExtract and other tables
	   for the Price, NCR Payment, Cash To Collect, Incentive for each job
	   and calc Subtotal price, spilt out NCR Payment JSON
	   filtered by Org and DateTime (based on declared variables)
	   into #Price temp table*/
	SELECT
		t.Id As pGetSwiftId,
		COALESCE(jm.TotalPrice, 0) As OrderAmount,
		JSON_VALUE(jm.NcrPayment, '$[0].Name') As TenderMode,
		(COALESCE(jm.TotalPrice, 0)) - (COALESCE(jm.CashToCollect, 0)) As TenderAmount,
		COALESCE(jm.CashToCollect, 0) As CashToCollect,
		COALESCE(t.DeliveryPrice, 0) As DeliveryCharge,
		COALESCE(i.Amount, 0) As IncentiveAmount
	INTO #Price
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		LEFT JOIN #JobMetadata jm ON jm.GetSwiftId = t.Id
		LEFT JOIN TransportJobIncentives ti WITH (NOLOCK) ON t.Identifier = ti.TransportJobId
		LEFT JOIN Incentives i WITH (NOLOCK) ON ti.IncentiveId = i.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract1, CashTransactionIncentives, TransportJobIncentives, CashDropTransactions and other tables
	   for the Job Id, CashDropID for each incentive
	   filtered by Org (and limited by join to #TransportJobsExtract1)
	   into #Incentive temp table*/
	SELECT
		t.GetSwiftId As iGetSwiftId,
		cdt.CashDropId As iCashDropId
	INTO #Incentive
	FROM CashTransactions ct WITH (NOLOCK)
		 INNER JOIN CashTransactionIncentives cti WITH (NOLOCK) ON cti.CashTransactionId = ct.Id
		 INNER JOIN TransportJobIncentives tji WITH (NOLOCK) ON cti.TransportJobIncentivesId = tji.Id
		 INNER JOIN #TransportJobsExtract1 t ON t.Identifier = tji.TransportJobId
		 LEFT JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
	WHERE
		ct.Type = 6
	ORDER BY
		t.GetSwiftId;

	/* Query CashTransactions table
	   with joins to #TransportJobsExtract, CashTransactionTransportJobs, CashDropTransactions, and other tables
	   for the Job Id, CashDropID for each "Collect from Customer" transaction
	   filtered by Org (and limited by join to #TransportJobsExtract)
	   into #CollectFromCustomer temp table*/
	SELECT
		t.GetSwiftId As cGetSwiftId,
		cdt.CashDropId As cCashDropId
	INTO #CollectFromCustomer
	FROM CashTransactions ct WITH (NOLOCK)
		INNER JOIN CashTransactionTransportJobs ctj WITH (NOLOCK) ON ctj.CashTransactionId = ct.Id
		INNER JOIN #TransportJobsExtract1 t ON t.GetSwiftId = ctj.TransportJobId
		LEFT JOIN CashDropTransactions cdt WITH (NOLOCK) ON ct.Id = cdt.CashTransactionId
	WHERE
		ct.Type = 0
	ORDER BY
		t.GetSwiftId;

	/* Using CTE, query #CollectFromCustomer temp table
	   and UNION join #Incentives table
	   to combine list of jobs with cash drops for "Collect From Customer" and list of jobs with cash drops for "Incentives"
	   for Job ID, CashDropId
	   grouped by Job ID (so no duplicate entries)
	   into #CashDropList temp table*/
	WITH CashDropCTE (Id, CashDropId) As
		(SELECT c.cGetSwiftId, c.cCashDropId FROM #CollectFromCustomer c
		UNION
		SELECT i.iGetSwiftId, i.iCashDropId FROM #Incentive i
		)
	SELECT
		MAX(c.Id) As Id,
		MAX(c.CashDropId) As CashDropId
	INTO #CashDropList
	FROM CashDropCTE c
	GROUP BY
		c.Id
	ORDER BY
		c.Id;

	/* Query #CashDropList temp table
	   with joins to CashDrops, CashDropTransactions
	   + CashTransactions (only on drop transactions, because CashTransactionAudits table only has records for drop and outlay), and other tables
	   for the Job Id, Cash Drop User, Cash Drop User Email, and Cash Drop Time
	   into #CashDrop temp table*/
	SELECT
		cdl.Id As cdGetSwiftId,
		CONCAT(a.FirstName,' ',a.LastName) As CashDropUser,
		a.Email As CashDropUserEmail,
		CAST(DATEADD(hour,@UTCOffset,c.DateTime) as varchar) 'CashDropDateTime'
	INTO #CashDrop
	FROM #CashDropList cdl
		INNER JOIN CashDropTransactions cdt WITH (NOLOCK) ON cdt.CashDropId = cdl.CashDropId
		INNER JOIN CashTransactions c WITH (NOLOCK) ON c.Id = cdt.CashTransactionId AND c.Type = 1 /* "Return to Store" type filter */
		LEFT JOIN CashTransactionAudits cta WITH (NOLOCK) ON cta.CashTransactionId = cdt.CashTransactionId
		LEFT JOIN Accounts a WITH (NOLOCK) ON a.Id = cta.AccountId
	ORDER BY
		cdl.Id;

	/* Join 4 intermediary temp tables into final #Output temp table */
	SELECT * INTO #Output FROM #TransportJobsExtract1 t
		LEFT JOIN #Price p ON t.GetSwiftId = p.pGetSwiftId
		LEFT JOIN #TransportJobsExtract2 tt ON t.GetSwiftId = tt.tGetSwiftId
		LEFT JOIN #CashDrop cd ON t.GetSwiftId = cd.cdGetSwiftId;

	/* Drop duplicate GetSwiftId columns used to join temp tables */
	ALTER TABLE #Output
		DROP COLUMN GetSwiftId, Identifier, pGetSwiftId, tGetSwiftId, cdGetSwiftId;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o
		WHERE o.OrderId NOT LIKE 'RM Email'
		ORDER BY o.InitialOrderTime;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#OrderStageEnum,
		#Accepted,
		#Abandon,
		#TransportJobsExtract1,
		#TransportJobsExtract2,
		#JobMetadata,
		#Price,
		#Incentive,
		#CollectFromCustomer,
		#CashDropList,
		#CashDrop,
		#Output;

END

/* Yum BI Report - Sep 27, 2019
Purpose: A query to pull month-to-date multi-Org-level Jobs report for Yum! Pizza Hut BI analysis
+ adding Order Batch Size and Order Batch Number fields using ImplicitlyPickedUp metadata*/

BEGIN
    /* Remove count of rows in export */
    SET NOCOUNT ON
    SET ANSI_WARNINGS OFF
    /* Declare variables */
    DECLARE @StartDateUTC DATETIME = DATEADD(hh,00,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-3)), /* This will give 3 days ago at 00:00 UTC */
            @EndDateUTC DATETIME = GETDATE(), /* This will give today's datetime when report is run */
            @OrgName1 VARCHAR(50) = 'Kout Food Group',
            @OrgName2 VARCHAR(50) = 'Sterling Qatar',
            @OrgName3 VARCHAR(50) = 'PH Jeddah',
            @OrgName4 VARCHAR(50) = 'PH Pakistan',
            @InitialCount INT,
            @FinalCount INT;

    /* Set the initial row count we expect the query should output
       This is based on total row count of TransportJobs table
       filtered by Org and DateTime (based on declared variables) */
    SET @InitialCount =
    (
    SELECT COUNT(*)
    FROM TransportJobs t WITH (NOLOCK)
        FULL OUTER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        FULL OUTER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC
    );

    /* Create #OrderStageEnum temp table
       to convert Driver Activity Enum to display text*/
    CREATE TABLE #OrderStageEnum (
        Id INT,
        DisplayText VARCHAR(MAX)
    );

    INSERT INTO #OrderStageEnum
    VALUES    (0,'Received'),
            (1,'Accepted'),
            (3,'En Route'),
            (5,'Completed'),
            (6,'Cancelled'),
            (7,'Abandoned');

    /* Create #ModeOfTransport temp table
       to convert Mode of Transport to display text*/
    CREATE TABLE #ModeofTransport (
        Id INT,
        DisplayText VARCHAR(MAX)
    );

    INSERT INTO #ModeofTransport
    VALUES    (0,'Car'),
            (1,'Walker'),
            (2,'Subway'),
            (3,'Bicycle'),
            (4,'Uber'),
            (5,'Truck'),
            (6,'Taxi'),
            (7,'Van'),
            (8,'Drone'),
            (9,'Motorbike'),
            (10,'Scooter');

    /* Query Accounts table
       with joins to AccountUsernames and other tables
       for the Username of account without email (no duplicates)
       filtered by Org and DateTime (based on declared variables)
       into #Usernames temp table*/
    SELECT
        MAX(h.Id) As DriverId,
        MAX(au.Username) As DriverUsername
    INTO #Usernames
    FROM Accounts a WITH (NOLOCK)
        INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
        INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
    GROUP BY
        a.Id
    ORDER BY
        a.Id;

    /* Using CTE, query TransportJobStageEntries table
       for Accepted entries (and row number if there are multiple entries)
       filtered by Org and DateTime (based on declared variables) and RowNumber = 1
       into #Accepted temp table*/
    WITH AcceptedCTE (Id, Created, RowNumber) AS
        (SELECT
            ts.TransportJobId,
            ts.Created,
            ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
                ORDER BY ts.Created DESC) AS RowNumber
        FROM TransportJobStageEntries ts WITH (NOLOCK)
            INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
            INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
            INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
        WHERE
            o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
            t.Created >= @StartDateUTC AND
            t.Completed < @EndDateUTC AND
            ts.Stage = 1 AND
            ts.Notes NOT LIKE '%at pickup%'
        )
    SELECT *
    INTO #Accepted
    FROM AcceptedCTE ac
    WHERE ac.RowNumber = 1;

    /* Using CTE, query TransportJobStageEntries table
       for Completed entries (and row number if there are multiple entries)
       for Latitude and Longitude
       filtered by Org and DateTime (based on declared variables) and RowNumber = 1
       into #Completed temp table*/
    WITH CompletedCTE (Id, Created, Latitude, Longitude, RowNumber) AS
        (SELECT
            ts.TransportJobId,
            ts.Created,
            ts.Latitude,
            ts.Longitude,
            ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
                ORDER BY ts.Created DESC) AS RowNumber
        FROM TransportJobStageEntries ts WITH (NOLOCK)
            INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
            INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
            INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
        WHERE
            o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
            t.Created >= @StartDateUTC AND
            t.Completed < @EndDateUTC AND
            ts.Stage = 5
        )
    SELECT *
    INTO #Completed
    FROM CompletedCTE cc
    WHERE cc.RowNumber = 1;

    /* Query TransportJobs table
       with joins to Handlers, Fleets, Accounts, #Accepted, and other tables
       filtered by Org and DateTime (based on declared variables)
       into #TransportJobsExtract temp table*/
    SELECT
        t.Id As GetSwiftId,
        t.Reference As SDMOrderId,
        replace(replace(replace(f.Name, char(39), ' '),char(34), ' '),char(124), ' ') as FleetName,
        m.Id As MerchantId,
        replace(replace(replace(m.Name, char(39), ' '),char(34), ' '),char(124), ' ') as MerchantName,
        replace(replace(replace(b.Name, char(39), ' '),char(34), ' '),char(124), ' ') as MerchantBrand,
        replace(replace(replace(o.Name, char(39), ' '),char(34), ' '),char(124), ' ') as OrgName,
        (CASE
            WHEN o.Name = 'Kout Food Group' THEN 'Kuwait'
            WHEN o.Name = 'Sterling Qatar' THEN 'Qatar'
            WHEN o.Name = 'PH Jeddah' THEN 'KSA Jeddah'
            WHEN o.Name = 'PH Pakistan' THEN 'Pakistan'
            ELSE 'Other' END)
            As ISOCountry,
        h.Id As DriverId,
        replace(replace(replace(u.DriverUsername, char(39), ' '),char(34), ' '),char(124), ' ') as DriverUsername,
        replace(replace(replace(a.FirstName, char(39), ' '),char(34), ' '),char(124), ' ') as DriverFirstName,
        replace(replace(replace(a.FirstName, char(39), ' '),char(34), ' '),char(124), ' ') as DriverLastName,
        mt.DisplayText As VehicleType,
        t.DropoffTime_LatestTime As PromiseTimeUTC,
        t.Created As CreatedUTC,
        t.OrderProcessed As InKitchenUTC,
        t.OrderReady As ReadyUTC,
        ac.Created As AcceptedUTC,
        t.ArrivedAtPickup As AtPickupUTC,
        t.OrderOnWay As EnRouteUTC,
        t.ArrivedAtDropoff As AtDropoffUTC,
        t.Completed As CompletedUTC,
        e.DisplayText As CurrentOrderStage,
        cc.Latitude As CompletedLatitude,
        cc.Longitude As CompletedLongitude,
        m.ExternalId As MerchantExternalId
    INTO #TransportJobsExtract
    FROM TransportJobs t WITH (NOLOCK)
        INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
        INNER JOIN #OrderStageEnum e ON e.Id = t.CurrentStage
        LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = t.FleetId
        LEFT JOIN Handlers h WITH (NOLOCK) ON t.HandlerId = h.Id
        LEFT JOIN #ModeofTransport mt ON mt.Id = h.ModeOfTransport
        LEFT JOIN #Usernames u ON u.DriverId = h.Id
        LEFT JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
        LEFT JOIN Brands b WITH (NOLOCK) ON m.Identifier = b.MerchantId
        LEFT JOIN #Accepted ac ON ac.Id = t.Id
        LEFT JOIN #Completed cc ON cc.Id = t.Id
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC
    ORDER BY
        t.Id;

    /* Query TransportJobs table
       with joins to TransportJobLocations and other tables
       for the pickup/dropoff location information for each job
       filtered by DateTime (based on declared variables) AND not org (can't create query plan)
       into #LocationsExtract temp table*/
    SELECT
        t.Id As lGetSwiftId,
        replace(replace(replace(tp.ContactName, char(39), ' '),char(34), ' '),char(124), ' ') as PickupName,
        replace(replace(replace(tp.Description, char(39), ' '),char(34), ' '),char(124), ' ') as PickupDescription,
        tp.ContactPhone As PickupPhone,
        tp.Latitude As PickupLatitude,
        tp.Longitude As PickupLongitude,
        td.Latitude As DropoffLatitude,
        td.Longitude As DropoffLongitude
    INTO #LocationsExtract
    FROM TransportJobs t WITH (NOLOCK)
        INNER JOIN TransportJobLocations tp WITH (NOLOCK) ON t.Id = tp.TransportJobId AND tp.Type = 0 /* Pickup location filter */
        INNER JOIN TransportJobLocations td WITH (NOLOCK) ON t.Id = td.TransportJobId AND td.Type = 1 /* Dropoff location filter */
    WHERE
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC
    ORDER BY
        t.Id;

    /* Query TransportJobMetadatas table
       with joins to TransportJobs and other tables
       for the Total Price information for each job
       filtered by Org and DateTime (based on declared variables)
       into #MetadataExtract temp table*/
    SELECT
        tm.TransportJobId As GetSwiftId,
        CAST(MAX(CASE WHEN tm.JobMetadata = 20 THEN tm.Value ELSE NULL END) As decimal(19,4)) As TotalPrice,
        MAX(CASE WHEN tm.JobMetadata = 21 THEN tm.ValueJson ELSE NULL END) As NcrPayment,
        CAST(MAX(CASE WHEN tm.JobMetadata = 9 THEN tm.Value ELSE NULL END) As decimal(19,4)) As CashToCollect
    INTO #MetadataExtract
    FROM TransportJobMetadatas tm WITH (NOLOCK)
        INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = tm.TransportJobId
        INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC AND
        tm.JobMetadata IN (9, 20, 21)
    GROUP BY tm.TransportJobId;

    /* Query TransportJobs table
       with joins to #MetadataExtract and other tables
       for the Price information for each job
       and calc Subtotal price
       filtered by Org and DateTime (based on declared variables)
       into #PriceExtract temp table*/
    SELECT
        t.Id As pGetSwiftId,
        CASE
        WHEN COALESCE(me.TotalPrice, 0) = 0 THEN 'Price is 0'
        WHEN COALESCE(me.CashToCollect, 0) = 0 THEN 'Prepaid'
        WHEN COALESCE(me.CashToCollect, 0) <> COALESCE(me.TotalPrice, 0) THEN 'Split'
        WHEN COALESCE(me.CashToCollect, 0) > 0 THEN 'Cash'
        ELSE 'Other' END
        As Payment,
        JSON_VALUE(me.NcrPayment, '$[0].Name') As PaymentTenderMode,
        COALESCE(me.TotalPrice, 0) As TotalPrice,
        (COALESCE(me.TotalPrice, 0)) - (COALESCE(t.DeliveryPrice, 0)) As SubtotalPrice,
        COALESCE(t.DeliveryPrice, 0) As DeliveryPrice
    INTO #PriceExtract
    FROM TransportJobs t WITH (NOLOCK)
        INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
        LEFT JOIN #MetadataExtract me ON me.GetSwiftId = t.Id
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC
    ORDER BY
        t.Id;

    /* Query TransportJobItems table
       with joins to TransportJobs and other tables
       for number of items in each order
       filtered by Org and DateTime (based on declared variables)
       into #PriceExtract temp table*/
    SELECT
        MAX(t.Id) As itGetSwiftId,
        COUNT(*) As CountofItems
    INTO #ItemsExtract
    FROM TransportJobItems ti WITH (NOLOCK)
        INNER JOIN TransportJobs t WITH (NOLOCK) ON t.Id = ti.TransportJobId
        INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC
    GROUP BY t.Id
    ORDER BY t.Id;

    /* Query TransportJobs table
       with joins to TransportJobMetadatas and other tables
       and calc order batch size and order batch number
       for the Implicitly PickedUp information for each job
       filtered by Org and DateTime (based on declared variables)
       into #ImplicitlyPickedUpExtract temp table*/
    SELECT
        t.Id As iGetSwiftId,
        tm.Value As ImplicitlyPickedUp,
        COUNT(*) OVER(PARTITION BY t.HandlerId, tm.Value) As OrderBatchSize,
        ROW_NUMBER() OVER(PARTITION BY t.HandlerId, tm.Value
            ORDER BY t.Completed ASC) As OrderBatchNumber,
        FIRST_VALUE(t.OrderOnWay) OVER(PARTITION BY t.HandlerId, tm.Value
        ORDER BY t.Completed ASC) AS NewEnRouteTimeUTC
    INTO #ImplicitlyPickedUpExtract
    FROM TransportJobs t WITH (NOLOCK)
        INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
        INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
        INNER JOIN TransportJobMetadatas tm WITH (NOLOCK) ON t.Id = tm.TransportJobId
    WHERE
        o.Name IN (@OrgName1, @OrgName2, @OrgName3, @OrgName4) AND
        t.Created >= @StartDateUTC AND
        t.Completed < @EndDateUTC AND
        tm.JobMetadata = 22; /* Implicitly PickedUp filter */

    /* Join 5 intermediary temp tables into final #Output temp table */
    SELECT
        t.*,
        l.PickupName,
        COALESCE(t.MerchantExternalId, l.PickupDescription) As PickupDescription,
        l.PickupPhone,
        l.PickupLatitude,
        l.PickupLongitude,
        l.DropoffLatitude,
        l.DropoffLongitude,
        p.*,
        it.*,
        i.*
    INTO #Output
    FROM #TransportJobsExtract t
        LEFT JOIN #LocationsExtract l ON t.GetSwiftId = l.lGetSwiftId
        LEFT JOIN #PriceExtract p ON t.GetSwiftId = p.pGetSwiftId
        LEFT JOIN #ItemsExtract it ON t.GetSwiftId = it.itGetSwiftId
        LEFT JOIN #ImplicitlyPickedUpExtract i ON t.GetSwiftId = i.iGetSwiftId;

    /* Drop duplicate GetSwiftId columns used to join temp tables */
    ALTER TABLE #Output
        DROP COLUMN pGetSwiftId, itGetSwiftId, iGetSwiftId, MerchantExternalId;

    /* Set the final row count that the query returned
       This is based on total row count of #Output temp table */
    SET @FinalCount =
    (
    SELECT COUNT(*) FROM #Output
    );

    /* Check whether InitialCount = FinalCount
       If TRUE, return #Output. If FALSE, return error message*/
    IF @InitialCount = @FinalCount
        SELECT * FROM #Output o
        WHERE
            o.CurrentOrderStage IN ('Completed', 'Cancelled') AND
            o.GetSwiftId <> 1025649
        ORDER BY o.OrgName, o.GetSwiftId;
    ELSE
        SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

    /* Drop temp tables created*/
    DROP TABLE
        #OrderStageEnum,
        #ModeofTransport,
        #Usernames,
        #Accepted,
        #Completed,
        #TransportJobsExtract,
        #LocationsExtract,
        #ImplicitlyPickedUpExtract,
        #MetadataExtract,
        #PriceExtract,
        #ItemsExtract,
        #Output;
END

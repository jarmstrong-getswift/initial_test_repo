/* KFG Hubs Report - Sep 25, 2019
Purpose: A query to pull a list of hubs (Fleets) for KFG
+ adding the lat, long of one merchant in the Fleet
+ driver max cash threshold for org */

BEGIN
	/* Remove count of rows in export */
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE	@OrgName VARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of Fleets table
	   filtered by Org */
	SET @InitialCount = 
	(
	SELECT COUNT(*)
	FROM Fleets f WITH (NOLOCK)
		FULL OUTER JOIN Organisations o WITH (NOLOCK) ON o.Identifier = f.OrganisationId
	WHERE 
		o.Name = @OrgName
	);

	/* Query Fleets table
	   with joins to TransportJobs, OrgConfigEntries, and other tables
	   for the Fleet info, latest transport job for that fleet,
	   + MaxHandlerCashHeld superadmin setting for org, and whether Fleet is still active
	   filtered by Org
	   into #Fleets temp table*/
	SELECT
		MAX(f.Id) As FleetId,
		MAX(f.Name) As FleetName,
		MAX(t.Id) As LatestTransportJob,
		MAX(oc.ConfigValue) As OrgMaxHandlerCashHeld,
		MAX(CASE WHEN f.Deleted = 0 THEN 'TRUE' ELSE 'FALSE' END) As HubActive
	INTO #Fleets
	FROM Fleets f WITH (NOLOCK)
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Identifier = f.OrganisationId
		INNER JOIN OrgConfigEntries oc WITH (NOLOCK) ON o.Id = oc.OrganisationId AND oc.MerchantConfigType = 56 /* 56 is the MaxHandlerCashHeld enum on Superadmin Org settings*/
		LEFT JOIN TransportJobs t WITH (NOLOCK) ON t.FleetId = f.Id
	WHERE 
		o.Name = @OrgName
	GROUP BY
		f.Id;

	/* Query #Fleets temp table
	   with joins to TransportJobLocations table
	   for Fleets info, lat long of one merchant in Fleet, MaxHandlerCashHeld for org, and Active fleet
	   filtered by Org
	   into #Output temp table*/
	SELECT
		f.FleetId As HubId,
		f.FleetName As HubName,
		CAST(tl.Latitude As varchar(MAX)) + ', ' + CAST(tl.Longitude As varchar(MAX)) As HubLocation,
		f.OrgMaxHandlerCashHeld As DriverThresholdAmount,
		f.HubActive As HubActive
	INTO #Output
	FROM #Fleets f
		LEFT JOIN TransportJobLocations tl WITH (NOLOCK) ON tl.TransportJobId = f.LatestTransportJob AND tl.Type = 0 /* 0 is the Type for Pickup Locations*/
	ORDER BY
		f.FleetName;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount = 
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount 
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount 
		SELECT * FROM #Output o 
		ORDER BY o.HubName;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#Fleets,
		#Output;

END

#!/bin/bash
USERNAME=$1
PASSWORD=$2
SERVER=$3
HOST_DIR=$4
TARGET_DIR=$5
KFG_OR_YUM=$6

echo ${USERNAME} ${PASSWORD} ${SERVER} ${HOST_DIR} ${TARGET_DIR}

cd ${HOST_DIR}

if [ ${KFG_OR_YUM} == "KFG" ]
then
  #sed command necessary to accomodate whitespace for subsequent zip command
  UPLOAD_FILES=`ls *csv|grep -v "PH BI Report" |tr '\n' ' '|sed -e 's/csv /csv|/g'`

elif [ ${KFG_OR_YUM} == "YUM" ]
then
  UPLOAD_FILES=`ls *csv|grep "PH BI Report"`

else
  echo "Sixth input token needs to be value 'KFG' or 'YUM'"
  exit 1
fi

echo "UPLOAD FILES are ${UPLOAD_FILES}"

if [ ${KFG_OR_YUM} == "KFG" ]
then
#rename file to full month name with leading zeroes trimmed off date number e.g., "April1.zip", "April2.zip"
#awkward sed command, but couldn't figure out a super elegant way to strip off leading zeroes
  to_zip_file=`date +%B.%d|sed 's/^0*//g; s/\.0*/./g; s/\.//g'`
  
  #we set the Internal Field Separator to pipe to successfully parse out the whitespaced filenames into tokens
  IFS=$'|'

  for i in ${UPLOAD_FILES};
  do
    zip ${to_zip_file}.zip ${i}
  done

  unset IFS

# apologies for not offsetting the EOF, but it was throwing an error when I tried to indent it... 
# login to remote ftps server
  lftp ftps://${USERNAME}:${PASSWORD}@${SERVER} -e "set ssl:verify-certificate false; set ftps:initial-prot ""; set ftp:ssl-force true; set ftp:ssl-protect-data true;" <<EOF
  echo cd ${TARGET_DIR}
  cd ${TARGET_DIR}
  echo lcd ${HOST_DIR}
  lcd ${HOST_DIR}
  echo ${to_zip_file}.zip
  put ${HOST_DIR}/${to_zip_file}.zip
  quit
EOF

# login to Yum sftp server
elif [ ${KFG_OR_YUM} == "YUM" ]
then
  /usr/bin/expect <<EOF
  spawn sftp -oStrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ${USERNAME}@${SERVER}
  expect "password:"
  send "${PASSWORD}\n" 
  expect "sftp> "
  send "cd ${TARGET_DIR}\n"
  expect "sftp> "
  send "lcd ${HOST_DIR}\n"
  expect "sftp> "
  send "mput \"${UPLOAD_FILES}\"\n"
  expect "sftp> "
  send "quit\n"
EOF

fi

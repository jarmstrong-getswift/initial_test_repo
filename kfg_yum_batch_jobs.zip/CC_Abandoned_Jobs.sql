--
-- CC Abandoned Jobs report query
--
BEGIN
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	/* Declare variables */
	DECLARE @UTCOffset INT = 3; /* Turn UTC time into local time*/
	DECLARE @StartDateLocal DATETIME = DATEADD(hh,06,DATEADD(dd,DATEDIFF(dd,0,GETDATE()),-2)), /* This will give 2 days ago at 06:00 Kuwait time */
			@EndDateLocal DATETIME = DATEADD(hh,@UTCOffset,GETDATE()), /* This will give today's datetime at report run */
			@OrgName NVARCHAR(50) = 'Kout Food Group',
			@InitialCount INT,
			@FinalCount INT;

	/* Set the initial row count we expect the query should output
	   This is based on total row count of TransportJobsStageEntries table
	   filtered on Stage = 7 (Abandoned)
	   filtered by Org and DateTime (based on declared variables) */
	SET @InitialCount =
	(
	SELECT COUNT(*)
	FROM TransportJobStageEntries ts WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		ts.Stage = 7
	);

	/* Create #OrderStageEnum temp table
	   to convert Driver Activity Enum to display text*/
	CREATE TABLE #OrderStageEnum (
		Id INT,
		DisplayText VARCHAR(MAX)
	);

	INSERT INTO #OrderStageEnum
	VALUES	(0,'Received'),
			(1,'Accepted'),
			(3,'En Route'),
			(5,'Completed'),
			(6,'Cancelled'),
			(7,'Abandoned');

	/* Using CTE, query TransportJobStageEntries table
	   for Accepted entries (and row number if there are multiple entries)
	   filtered by Org and DateTime (based on declared variables) and RowNumber = 1
	   into #Accepted temp table*/
	WITH AcceptedCTE (Id, Created, RowNumber) AS
		(SELECT
			ts.TransportJobId,
			ts.Created,
			ROW_NUMBER() OVER(PARTITION BY ts.TransportJobId
				ORDER BY ts.Created DESC) AS RowNumber
		FROM TransportJobStageEntries ts WITH (NOLOCK)
			INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
			INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
			INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		WHERE
			o.Name = @OrgName AND
			DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
			DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
			ts.Stage = 1 AND
			ts.Notes NOT LIKE '%at pickup%'
		)
	SELECT *
	INTO #Accepted
	FROM AcceptedCTE ac
	WHERE ac.RowNumber = 1
	ORDER BY ac.Id;

	/* Query TransportJobStageEntries table
	   with joins to TransportJobs and other tables
	   for Abandoned entries
	   filtered by Org and DateTime (based on declared variables) Stage = 7
	   into #Abandon temp table*/
	SELECT
		ts.TransportJobId As Id,
		ts.Created,
		ts.Notes
	INTO #Abandon
	FROM TransportJobStageEntries ts WITH (NOLOCK)
		INNER JOIN TransportJobs t WITH (NOLOCK) ON ts.TransportJobId = t.Id
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal AND
		ts.Stage = 7;

	/* Query Accounts table
	   with joins to AccountUsernames and other tables
	   for the Username of account without email (no duplicates)
	   filtered by Org and DateTime (based on declared variables)
	   into #Usernames temp table*/
	SELECT
		MAX(h.Id) As DriverId,
		MAX(au.Username) As DriverUsername
	INTO #Usernames
	FROM Accounts a WITH (NOLOCK)
		INNER JOIN AccountUsernames au WITH (NOLOCK) ON a.Id = au.AccountId
		INNER JOIN Handlers h WITH (NOLOCK) ON h.AccountId = a.Id
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = h.OrganisationId
	WHERE
		o.Name = @OrgName AND
		au.Username NOT LIKE '%@%' /* Filter out Email rows in Account Username table*/
	GROUP BY
		a.Id
	ORDER BY
		a.Id;

	/* Query TransportJobs table
	   with joins to Handlers, Fleets, Accounts, #Accepted, #Abandon and other tables
	   filtered by Org and DateTime (based on declared variables)
	   into #TransportJobsExtract temp table*/
	SELECT
		t.Id As GetSwiftId,
		t.Reference As Reference,
		f.Name As FleetName,
		m.Id As MerchantId,
		m.Name As MerchantName,
		h.Id As DriverId,
		u.DriverUsername As DriverUsername,
		a.FirstName As DriverFirstName,
		a.LastName As DriverLastName,
		e.DisplayText As OrderStatus,
		CAST(DATEADD(hour,@UTCOffset,t.DropoffTime_LatestTime) as varchar) As 'PromiseTimeLocal',
		CAST(DATEADD(hour,@UTCOffset,t.Created) as varchar) As 'CreatedLocal',
		CAST(DATEADD(hour,@UTCOffset,t.OrderProcessed) as varchar) As 'InKitchenLocal',
		CAST(DATEADD(hour,@UTCOffset,t.OrderReady) as varchar) As 'ReadyLocal',
		CAST(DATEADD(hour,@UTCOffset,ac.Created) as varchar) As 'AcceptedLocal',
		CAST(DATEADD(hour,@UTCOffset,t.ArrivedAtPickup) as varchar) As 'AtPickupLocal',
		CAST(DATEADD(hour,@UTCOffset,t.OrderOnWay) as varchar) As 'EnRouteLocal',
		CAST(DATEADD(hour,@UTCOffset,t.ArrivedAtDropoff) as varchar) As 'AtDropoffLocal',
		CAST(DATEADD(hour,@UTCOffset,t.Completed) as varchar) As 'CompletedLocal',
		CAST(DATEADD(hour,@UTCOffset,ab.Created) as varchar) As 'AbandonedLocal',
		CAST(DATEFROMPARTS(YEAR(DATEADD(hour,@UTCOffset-6,t.Created)),MONTH(DATEADD(hour,@UTCOffset-6,t.Created)),DAY(DATEADD(hour,@UTCOffset-6,t.Created))) as varchar) As 'DOB',
		ab.Notes As AbandonedDetails
	INTO #TransportJobsExtract
	FROM TransportJobs t WITH (NOLOCK)
		INNER JOIN Merchants m WITH (NOLOCK) ON m.Id = t.MerchantId
		INNER JOIN Organisations o WITH (NOLOCK) ON o.Id = m.OrganisationId
		INNER JOIN #OrderStageEnum e ON e.Id = t.CurrentStage
		INNER JOIN #Abandon ab ON ab.Id = t.Id
		LEFT JOIN Fleets f WITH (NOLOCK) ON f.Id = t.FleetId
		LEFT JOIN Handlers h WITH (NOLOCK) ON t.HandlerId = h.Id
		LEFT JOIN Accounts a WITH (NOLOCK) ON a.Id = h.AccountId
		LEFT JOIN #Usernames u ON u.DriverId = h.id
		LEFT JOIN #Accepted ac ON ac.Id = t.Id
	WHERE
		o.Name = @OrgName AND
		DATEADD(hour,@UTCOffset,t.Created) >= @StartDateLocal AND
		DATEADD(hour,@UTCOffset,t.Completed) < @EndDateLocal
	ORDER BY
		t.Id;

	/* Join 1 intermediary temp tables into final #Output temp table
	 + adding count of abandoned entries per job */
	SELECT
		*,
		COUNT(*) OVER(PARTITION BY t.GetSwiftId) As AbandonedCount
	INTO #Output
	FROM #TransportJobsExtract t;

	/* Set the final row count that the query returned
	   This is based on total row count of #Output temp table */
	SET @FinalCount =
	(
	SELECT COUNT(*) FROM #Output
	);

	/* Check whether InitialCount = FinalCount
	   If TRUE, return #Output. If FALSE, return error message*/
	IF @InitialCount = @FinalCount
		SELECT * FROM #Output o
		WHERE o.GetSwiftId NOT LIKE 1025649
		ORDER BY o.GetSwiftId;
	ELSE
		SELECT CONCAT ('Initial row count (', @InitialCount, ') and final row count (', @FinalCount, ') does not match. Please check table joins.') As Error;

	/* Drop temp tables created*/
	DROP TABLE
		#OrderStageEnum,
		#Accepted,
		#Abandon,
		#Usernames,
		#TransportJobsExtract,
		#Output;
END

package org.talend.designer.codegen.translators.databasesnosql.cassandra;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.core.model.process.IConnection;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.core.model.utils.NodeUtil;
import java.util.List;
import java.util.Map;

public class TCassandraRowMainJava
{
  protected static String nl;
  public static synchronized TCassandraRowMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TCassandraRowMainJava result = new TCassandraRowMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "    \t";
  protected final String TEXT_3 = NL + "        com.datastax.driver.core.Cluster cluster_";
  protected final String TEXT_4 = " = (com.datastax.driver.core.Cluster)globalMap.get(\"cluster_";
  protected final String TEXT_5 = "\");" + NL + "        com.datastax.driver.core.Session connection_";
  protected final String TEXT_6 = " = (com.datastax.driver.core.Session)globalMap.get(\"connection_";
  protected final String TEXT_7 = "\");";
  protected final String TEXT_8 = NL + "\t";
  protected final String TEXT_9 = NL + "\t\tjavax.net.ssl.KeyManagerFactory kmf_";
  protected final String TEXT_10 = " = null;" + NL + "\t\t";
  protected final String TEXT_11 = NL + "\t\t\tjava.security.KeyStore ks_";
  protected final String TEXT_12 = " = java.security.KeyStore.getInstance(\"";
  protected final String TEXT_13 = "\");" + NL + "\t\t\tks_";
  protected final String TEXT_14 = ".load(new java.io.FileInputStream(";
  protected final String TEXT_15 = "), ";
  protected final String TEXT_16 = ".toCharArray());" + NL + "\t\t\tkmf_";
  protected final String TEXT_17 = " = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());" + NL + "\t\t\tkmf_";
  protected final String TEXT_18 = ".init(ks_";
  protected final String TEXT_19 = ", ";
  protected final String TEXT_20 = ".toCharArray());" + NL + "\t\t";
  protected final String TEXT_21 = NL + "\t\t" + NL + "\t\tjava.security.KeyStore ts_";
  protected final String TEXT_22 = "\");" + NL + "\t\tts_";
  protected final String TEXT_23 = ".toCharArray());" + NL + "\t\tjavax.net.ssl.TrustManagerFactory tmf_";
  protected final String TEXT_24 = " = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm());" + NL + "    \ttmf_";
  protected final String TEXT_25 = ".init(ts_";
  protected final String TEXT_26 = ");" + NL + "\t\t" + NL + "\t\tjavax.net.ssl.SSLContext sslContext_";
  protected final String TEXT_27 = " = javax.net.ssl.SSLContext.getInstance(\"TLS\");" + NL + "\t\tsslContext_";
  protected final String TEXT_28 = ".init(kmf_";
  protected final String TEXT_29 = " == null ? null : kmf_";
  protected final String TEXT_30 = ".getKeyManagers(), tmf_";
  protected final String TEXT_31 = ".getTrustManagers(), new java.security.SecureRandom());" + NL + "\t";
  protected final String TEXT_32 = NL + "    com.datastax.driver.core.Cluster cluster_";
  protected final String TEXT_33 = " = com.datastax.driver.core.Cluster.builder()" + NL + "    \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t.addContactPoints(";
  protected final String TEXT_34 = ".split(\",\"))" + NL + "    \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t.withPort(Integer.valueOf(";
  protected final String TEXT_35 = "))" + NL + "                                                            \t";
  protected final String TEXT_36 = NL + "                                                                \t.withCredentials(";
  protected final String TEXT_37 = ")" + NL + "                                                            \t";
  protected final String TEXT_38 = NL + "                                                            \t\t.withSSL(com.datastax.driver.core.JdkSSLOptions.builder()" + NL + "                                                            \t\t\t\t\t.withSSLContext(sslContext_";
  protected final String TEXT_39 = ").build())" + NL + "                                                            \t";
  protected final String TEXT_40 = NL + "    \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t.build();" + NL + "\t" + NL + "\tcom.datastax.driver.core.Session connection_";
  protected final String TEXT_41 = " = null;" + NL + "\tconnection_";
  protected final String TEXT_42 = " = cluster_";
  protected final String TEXT_43 = ".connect();" + NL + "        resourceMap.put(\"cluster_";
  protected final String TEXT_44 = "\", cluster_";
  protected final String TEXT_45 = ");" + NL + "        resourceMap.put(\"connection_";
  protected final String TEXT_46 = "\", connection_";
  protected final String TEXT_47 = ");";
  protected final String TEXT_48 = NL + "    try{" + NL + "    \tconnection_";
  protected final String TEXT_49 = ".execute(";
  protected final String TEXT_50 = ");" + NL + "    }catch(java.lang.Exception e){" + NL + "    \t";
  protected final String TEXT_51 = NL + "    \t\tthrow(e);" + NL + "    \t";
  protected final String TEXT_52 = NL + "    \t\tSystem.err.println(e.getMessage());" + NL + "    \t";
  protected final String TEXT_53 = NL + "    }";
  protected final String TEXT_54 = NL + "        connection_";
  protected final String TEXT_55 = ".close();" + NL + "        cluster_";
  protected final String TEXT_56 = ".close();";
  protected final String TEXT_57 = "    ";
  protected final String TEXT_58 = NL + "\t\tme.prettyprint.hector.api.Cluster cluster_";
  protected final String TEXT_59 = " =null;" + NL + "\t\tme.prettyprint.hector.api.Keyspace keyspace_";
  protected final String TEXT_60 = " =null;" + NL + "\t\ttry{";
  protected final String TEXT_61 = NL + "\t\tcluster_";
  protected final String TEXT_62 = "=(me.prettyprint.hector.api.Cluster)globalMap.get(\"cluster_";
  protected final String TEXT_63 = NL + "\t\t\tString hostIps_";
  protected final String TEXT_64 = "=";
  protected final String TEXT_65 = "+\":\"+";
  protected final String TEXT_66 = ";" + NL + "\t\t\tme.prettyprint.cassandra.service.CassandraHostConfigurator hosts_";
  protected final String TEXT_67 = " = new me.prettyprint.cassandra.service.CassandraHostConfigurator(hostIps_";
  protected final String TEXT_68 = ");" + NL + "\t\t\tjava.util.Map<String, String> credentials_";
  protected final String TEXT_69 = " = new java.util.HashMap<String, String>();";
  protected final String TEXT_70 = NL + "\t\t\tcredentials_";
  protected final String TEXT_71 = ".put(\"username\",";
  protected final String TEXT_72 = ");" + NL + "\t\t\t";
  protected final String TEXT_73 = NL + "            ";
  protected final String TEXT_74 = " " + NL + "\tfinal String decryptedPassword_";
  protected final String TEXT_75 = " = routines.system.PasswordEncryptUtil.decryptPassword(";
  protected final String TEXT_76 = NL + "\tfinal String decryptedPassword_";
  protected final String TEXT_77 = " = ";
  protected final String TEXT_78 = "; ";
  protected final String TEXT_79 = NL + "\t\t\t" + NL + "\t\t\t" + NL + "\t\t\tcredentials_";
  protected final String TEXT_80 = ".put(\"password\",decryptedPassword_";
  protected final String TEXT_81 = NL + "\t\t\tcluster_";
  protected final String TEXT_82 = " = me.prettyprint.hector.api.factory.HFactory.getOrCreateCluster(\"cluster_";
  protected final String TEXT_83 = "_\"+pid,hosts_";
  protected final String TEXT_84 = ",credentials_";
  protected final String TEXT_85 = NL + "\t\t\tme.prettyprint.cassandra.model.ConfigurableConsistencyLevel clpolicy_";
  protected final String TEXT_86 = " = new me.prettyprint.cassandra.model.ConfigurableConsistencyLevel();" + NL + "\t\t\tme.prettyprint.hector.api.HConsistencyLevel consistencyLevel_";
  protected final String TEXT_87 = " = me.prettyprint.hector.api.HConsistencyLevel.ONE;" + NL + "\t\t\tclpolicy_";
  protected final String TEXT_88 = ".setDefaultWriteConsistencyLevel(consistencyLevel_";
  protected final String TEXT_89 = ");" + NL + "\t\t\tkeyspace_";
  protected final String TEXT_90 = " = me.prettyprint.hector.api.factory.HFactory.createKeyspace(";
  protected final String TEXT_91 = ", cluster_";
  protected final String TEXT_92 = ",clpolicy_";
  protected final String TEXT_93 = ");" + NL + "\t\t\tme.prettyprint.cassandra.model.CqlQuery cql_";
  protected final String TEXT_94 = "=new me.prettyprint.cassandra.model.CqlQuery(keyspace_";
  protected final String TEXT_95 = ",me.prettyprint.cassandra.serializers.StringSerializer.get()," + NL + "\t\t\t\tme.prettyprint.cassandra.serializers.StringSerializer.get(),me.prettyprint.cassandra.serializers.StringSerializer.get());" + NL + "\t\t\tcql_";
  protected final String TEXT_96 = ".setQuery(";
  protected final String TEXT_97 = ");" + NL + "\t\t\tcql_";
  protected final String TEXT_98 = ".execute();" + NL + "\t\t}catch(Exception e_";
  protected final String TEXT_99 = "){";
  protected final String TEXT_100 = NL + "\t\t\tthrow(e_";
  protected final String TEXT_101 = NL + "\t\t\tSystem.err.println(e_";
  protected final String TEXT_102 = ".getMessage());";
  protected final String TEXT_103 = NL + "\t\t}finally{" + NL + "\t\t\tif(cluster_";
  protected final String TEXT_104 = "!=null){" + NL + "\t\t\t\tcluster_";
  protected final String TEXT_105 = ".getConnectionManager().shutdown();" + NL + "\t\t\t}" + NL + "\t\t}";
  protected final String TEXT_106 = NL + "\t\t}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     
	CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
    INode node = (INode)codeGenArgument.getArgument();
    String cid = node.getUniqueName();
    
    
// Check the presence of a tCassandraConnection
{
    boolean useExistingConnection = ElementParameterParser.getBooleanValue(node,"__USE_EXISTING_CONNECTION__");
    if (useExistingConnection) {
        String connection = ElementParameterParser.getValue(node, "__CONNECTION__");
        if (connection.isEmpty()) {
            return "if (true) {throw new IOException(\"You have to selection a connection\");}";
        }
    }
}

    stringBuffer.append(TEXT_1);
    
//TODO: use API_SELECTED instead of this
class API_selector{
	public boolean useDatastax(INode node){
		String dbVersion = ElementParameterParser.getValue(node, "__DB_VERSION__");
        String apiType = ElementParameterParser.getValue(node, "__API_TYPE__");
        return "CASSANDRA_2_2".equals(dbVersion) || "CASSANDRA_3_0".equals(dbVersion) || ("CASSANDRA_2_0_0".equals(dbVersion) && "DATASTAX".equals(apiType)); 
	}
}	

    
	if((new API_selector()).useDatastax(ElementParameterParser.getBooleanValue(node, "__USE_EXISTING_CONNECTION__") ? ElementParameterParser.getLinkedNodeValue(node, "__CONNECTION__") : node)){
	
    stringBuffer.append(TEXT_2);
     
    boolean useExistConn = ElementParameterParser.getBooleanValue(node, "__USE_EXISTING_CONNECTION__");
    String connection = ElementParameterParser.getValue(node, "__CONNECTION__");
    if(useExistConn){
    
    stringBuffer.append(TEXT_3);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(connection);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(connection);
    stringBuffer.append(TEXT_7);
    
    }else{  
    
    stringBuffer.append(TEXT_8);
    
class SSL_HELPER{
	INode node;
	
	public SSL_HELPER(INode node){
		this.node = node;
	}
	
	public boolean useHTTPS() {
        return node != null;
    }
	
	public String getTSType(){
		return ElementParameterParser.getValue(node, "__TRUSTSTORE_TYPE__");
	}
	
	public String getTSPath(){
		return ElementParameterParser.getValue(node,"__SSL_TRUSTSERVER_TRUSTSTORE__");
	}
	
	public String getTSPwd(){
		return ElementParameterParser.getPasswordValue(node,"__SSL_TRUSTSERVER_PASSWORD__");
	}
	
	public boolean needKS(){
		return ElementParameterParser.getBooleanValue(node,"__NEED_CLIENT_AUTH__");
	}
	
	public String getKSType(){
		return ElementParameterParser.getValue(node, "__KEYSTORE_TYPE__");
	}
	
	public String getKSPath(){
		return ElementParameterParser.getValue(node,"__SSL_KEYSTORE__");
	}
	
	public String getKSPwd(){
		return ElementParameterParser.getPasswordValue(node,"__SSL_KEYSTORE_PASSWORD__");
	}
	
	public boolean needVerifyHostname(){
		return ElementParameterParser.getBooleanValue(node,"__VERIFY_NAME__");
	}
}	

    stringBuffer.append(TEXT_8);
    
    String host = ElementParameterParser.getValue(node,"__HOST__");
    String port = ElementParameterParser.getValue(node,"__PORT__");
    String userName = ElementParameterParser.getValue(node, "__USERNAME__");
    String passWord = ElementParameterParser.getPasswordValue(node, "__PASSWORD__");
	boolean authentication = ElementParameterParser.getBooleanValue(node, "__REQUIRED_AUTHENTICATION__");
	INode sslNode = ElementParameterParser.getLinkedNodeValue(node, "__HTTPS_SETTING__");
	SSL_HELPER sslHelper = new SSL_HELPER(sslNode);
	boolean useSSL = ElementParameterParser.getBooleanValue(node, "__USE_HTTPS__") && sslHelper.useHTTPS();
	if(useSSL){
	
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    if(sslHelper.needKS()){
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(sslHelper.getKSType());
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(sslHelper.getKSPath());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(sslHelper.getKSPwd());
    stringBuffer.append(TEXT_16);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(sslHelper.getKSPwd());
    stringBuffer.append(TEXT_20);
    }
    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(sslHelper.getTSType());
    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(sslHelper.getTSPath());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(sslHelper.getTSPwd());
    stringBuffer.append(TEXT_23);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_30);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    
	}
    
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(host);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(port);
    stringBuffer.append(TEXT_35);
    
                                                            	if(authentication){
                                                            	
    stringBuffer.append(TEXT_36);
    stringBuffer.append(userName);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(passWord);
    stringBuffer.append(TEXT_37);
    
                                                            	}
                                                            	if(useSSL){
                                                            	
    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    
                                                            	}
                                                            	
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    
    }
    Boolean dieOnError = ElementParameterParser.getBooleanValue(node, "__DIE_ON_ERROR__");
    String query = ElementParameterParser.getValue(node, "__QUERY__").replaceAll("[\r\n]", " ");
    
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(query);
    stringBuffer.append(TEXT_50);
    
    	if(dieOnError){
    	
    stringBuffer.append(TEXT_51);
    
    	}else{
    	
    stringBuffer.append(TEXT_52);
    
    	}
    	
    stringBuffer.append(TEXT_53);
     
    if(!useExistConn){
    
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    
    }
    
    
    }else{
    
    stringBuffer.append(TEXT_57);
    
	String host = ElementParameterParser.getValue(node,"__HOST__");
    String port = ElementParameterParser.getValue(node,"__PORT__");
    //String cluster= ElementParameterParser.getValue(node, "__CLUSTER__");
    String userName = ElementParameterParser.getValue(node, "__USERNAME__");
    String passWord = ElementParameterParser.getValue(node, "__PASSWORD__");
	String keySpace = ElementParameterParser.getValue(node,"__KEY_SPACE__");
	boolean authentication="true".equalsIgnoreCase(ElementParameterParser.getValue(node, "__REQUIRED_AUTHENTICATION__"));
    boolean useExistingConnection = "true".equalsIgnoreCase(ElementParameterParser.getValue(node,"__USE_EXISTING_CONNECTION__"));
    String columnFamily = ElementParameterParser.getValue(node,"__COLUMN_FAMILY__");
    String query = ElementParameterParser.getValue(node,"__QUERY__");
    query = query.replaceAll("\n"," ");
    query = query.replaceAll("\r"," ");
    boolean dieOnError = "true".equalsIgnoreCase(ElementParameterParser.getValue(node, "__DIE_ON_ERROR__"));

    stringBuffer.append(TEXT_58);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    
	if (useExistingConnection){
		String connection = ElementParameterParser.getValue(node, "__CONNECTION__");

    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(connection);
    stringBuffer.append(TEXT_7);
    
	}else{

    stringBuffer.append(TEXT_63);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_64);
    stringBuffer.append(host);
    stringBuffer.append(TEXT_65);
    stringBuffer.append(port);
    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_67);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_69);
    
		if (authentication){

    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(userName);
    stringBuffer.append(TEXT_72);
    
            String passwordFieldName = "__PASSWORD__";
            
    stringBuffer.append(TEXT_73);
    if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
    stringBuffer.append(TEXT_74);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_75);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_47);
    } else {
    stringBuffer.append(TEXT_76);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_77);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_78);
    }
    stringBuffer.append(TEXT_79);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_80);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    
		}

    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_82);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_84);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    
	}

    stringBuffer.append(TEXT_85);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_89);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_90);
    stringBuffer.append(keySpace);
    stringBuffer.append(TEXT_91);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_92);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_93);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_94);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_96);
    stringBuffer.append(query);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_99);
    
	if(dieOnError){

    stringBuffer.append(TEXT_100);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    
	}else{

    stringBuffer.append(TEXT_101);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_102);
    
	}
	if (!useExistingConnection){

    stringBuffer.append(TEXT_103);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_105);
    
	}else{

    stringBuffer.append(TEXT_106);
    
	}

    stringBuffer.append(TEXT_2);
    
    }
    
    return stringBuffer.toString();
  }
}
